﻿// WorldGenPipeline.cpp
#include "WorldGenPipeline.h"
#include "../Core/WorldForgeRNG.h"
#include "GameplayTagContainer.h"
#include "../Civilization/CivilizationGenerator.h"
#include "../Civilization/HistoricalSimulation.h"
#include "../Civilization/WorldHistory/WorldHistoryGenerator.h"
#include "../Civilization/WorldHistory/WorldHistoryContext.h"
#include "../Economy/WorldEconomySimulation.h"
#include "VoxelWorldManager.h"

namespace
{
    static FString CleanNameArtifacts(const FString& Input)
    {
        FString Result = Input;

        // Remove triple repeated characters (rrr -> rr)
        for (int32 i = 0; i < Result.Len() - 2; ++i)
        {
            if (Result[i] == Result[i + 1] && Result[i] == Result[i + 2])
            {
                Result.RemoveAt(i + 2);
                --i;
            }
        }

        // Remove repeated 2-letter syllables (e.g. riri -> ri)
        for (int32 i = 0; i < Result.Len() - 3; ++i)
        {
            if (Result[i] == Result[i + 2] &&
                Result[i + 1] == Result[i + 3])
            {
                Result.RemoveAt(i + 2, 2);
                --i;
            }
        }

        // Keep previous replacements (safe)
        Result.ReplaceInline(TEXT("ririr"), TEXT("rir"));
        Result.ReplaceInline(TEXT("lalal"), TEXT("lal"));

        return Result;
    }

    static FVector2D Rotate2D(const FVector2D& Vec, float Degrees)
    {
        const float Rad = FMath::DegreesToRadians(Degrees);
        const float C = FMath::Cos(Rad);
        const float S = FMath::Sin(Rad);

        return FVector2D(
            Vec.X * C - Vec.Y * S,
            Vec.X * S + Vec.Y * C
        );
    }

    static float DistanceToSegment2D(const FVector2D& P, const FVector2D& A, const FVector2D& B)
    {
        const FVector2D AB = B - A;
        const float Denom = FVector2D::DotProduct(AB, AB);

        if (Denom <= KINDA_SMALL_NUMBER)
        {
            return FVector2D::Distance(P, A);
        }

        const float T = FMath::Clamp(FVector2D::DotProduct(P - A, AB) / Denom, 0.f, 1.f);
        const FVector2D Closest = A + AB * T;
        return FVector2D::Distance(P, Closest);
    }

    static float GaussianLikeFalloff(float NormalizedDistance, float Sharpness)
    {
        return FMath::Exp(-NormalizedDistance * NormalizedDistance * Sharpness);
    }

    static float CalculateMountainContributionAtTile(
        const FVector2D& Tile,
        const TArray<FMountainRange>& Ranges,
        float FalloffSharpness)
    {
        float Total = 0.f;

        for (const FMountainRange& Range : Ranges)
        {
            const FVector2D End = Range.Start + Range.Direction * Range.Length;
            const float Distance = DistanceToSegment2D(Tile, Range.Start, End);

            const float RidgeNorm = Distance / FMath::Max(Range.Width, 1.f);
            const float Ridge = GaussianLikeFalloff(RidgeNorm, FalloffSharpness) * Range.HeightMultiplier;

            float Basin = 0.f;
            if (Range.BasinWidth > KINDA_SMALL_NUMBER && Range.BasinStrength > KINDA_SMALL_NUMBER)
            {
                const float BasinDistance = FMath::Abs(Distance - Range.BasinOffset);
                const float BasinNorm = BasinDistance / Range.BasinWidth;
                Basin = GaussianLikeFalloff(BasinNorm, FalloffSharpness) * Range.BasinStrength;
            }

            Total += (Ridge - Basin);
        }

        return Total;
    }
}

void UWorldGenPipeline::GenerateWorld(
    int64 InWorldSeed,
    FWorldGenConfig Config,
    UWorldForgeRNG* RNG)
{
    bComplete = false;
    CurrentConfig = Config;
    WorldSeed = InWorldSeed;
    RNGRef = RNG;
    WorldRef = GetOuter() ? GetOuter()->GetWorld() : nullptr;
    GridWidth = GetDimension(Config.WorldSize);
    GridHeight = GridWidth;

    if (!RNGRef)
    {
        UE_LOG(LogTemp, Error, TEXT("[WorldGen] GenerateWorld: RNG is null! Aborting."));
        return;
    }

    // Reset generated results for repeat-safe execution
    Civilizations.Reset();
    HistoryLog.Reset();
    Currencies.Reset();
    WorldTraits.Reset();
    MountainRanges.Reset();
    MountainProvinces.Reset();

    // Allocate tiles
    WorldTiles.SetNum(GridWidth * GridHeight);
    for (int32 i = 0; i < WorldTiles.Num(); i++)
    {
        WorldTiles[i].TileID = i;
        WorldTiles[i].KnowledgeState.TileID = i;
        WorldTiles[i].KnowledgeState.KnowledgeLevel = EKnowledgeLevel::Unexplored;
    }

    UE_LOG(LogTemp, Log, TEXT("[WorldGen] Start Seed=%lld Grid=%dx%d"),
        WorldSeed, GridWidth, GridHeight);

    Step01_InitializeSeed();
    Step02_GenerateHeightmap();
    Step03_RunTectonics();
    Step04_AssignBiomes();
    Step05_InitVoxelChunks();
    Step06_PCGDecorationPass();
    Step07_ApplyWorldDriver();
    Step08_SeedResources();
    Step09_PlaceCivilizations();
    Step10_GenerateCulturalDNA();
    Step11_GenerateEconomyLayer();
    Step12_GenerateCosmicRoster();
    Step13_RunPreHistory();
    Step14_AssignWorldTraits();
    Step15_RecordFinalState();
    Step16_FinalizeWorldMap();

    bComplete = true;
    UE_LOG(LogTemp, Log,
        TEXT("[WorldGen] Complete Tiles=%d Civs=%d Events=%d Currencies=%d"),
        WorldTiles.Num(), Civilizations.Num(),
        HistoryLog.Num(), Currencies.Num());
}

void UWorldGenPipeline::HandlePCGDecorationPass_Implementation(const TArray<FWorldTileData>& InWorldTiles, int32 InGridWidth, int32 InGridHeight)
{
    UE_LOG(
        LogTemp,
        Log,
        TEXT("[WorldGen] HandlePCGDecorationPass default implementation. Tiles=%d Grid=%dx%d"),
        InWorldTiles.Num(),
        InGridWidth,
        InGridHeight
    );
}

int32 UWorldGenPipeline::GetDimension(EWorldSize S) const
{
    switch (S)
    {
    case EWorldSize::Small:  return 128;
    case EWorldSize::Large:  return 512;
    case EWorldSize::OMG:    return 1024;
    default:                 return 256;
    }
}

void UWorldGenPipeline::Step01_InitializeSeed()
{
    RNGRef->InitializeWithSeed(WorldSeed);
    UE_LOG(LogTemp, Log, TEXT("[WorldGen] Step01 done"));
}

void UWorldGenPipeline::Step02_GenerateHeightmap()
{
    UE_LOG(LogTemp, Log, TEXT("[WorldGen] Step02: Heightmap..."));

    // Deterministic offsets so the same seed always produces the same macro world,
    // without every map looking centered on the same Perlin coordinates.
    const float TerrainOffsetX = RNGRef->NextFloatRange(UWorldForgeRNG::BRANCH_TERRAIN, -10000.0f, 10000.0f);
    const float TerrainOffsetY = RNGRef->NextFloatRange(UWorldForgeRNG::BRANCH_TERRAIN, -10000.0f, 10000.0f);

    const float BiomeOffsetX = RNGRef->NextFloatRange(UWorldForgeRNG::BRANCH_BIOME, -10000.0f, 10000.0f);
    const float BiomeOffsetY = RNGRef->NextFloatRange(UWorldForgeRNG::BRANCH_BIOME, -10000.0f, 10000.0f);

    // Large-scale continent shape
    const float MacroScaleA = 0.0060f;
    const float MacroScaleB = 0.0120f;
    const float DetailScale = 0.0280f;

    // Biome field scales
    const float TempScale = 0.0100f;
    const float RainScale = 0.0130f;

    const FVector2D MapCenter((GridWidth - 1) * 0.5f, (GridHeight - 1) * 0.5f);
    const float MaxCenterDist = FVector2D::Distance(FVector2D(0.0f, 0.0f), MapCenter);

    for (int32 Y = 0; Y < GridHeight; Y++)
    {
        for (int32 X = 0; X < GridWidth; X++)
        {
            FWorldTileData& Tile = WorldTiles[TileIndex(X, Y)];

            const float SX = static_cast<float>(X);
            const float SY = static_cast<float>(Y);

            // --- Base elevation: coherent macro landmass ---
            const float MacroA = FMath::PerlinNoise2D(FVector2D(
                (SX + TerrainOffsetX) * MacroScaleA,
                (SY + TerrainOffsetY) * MacroScaleA));

            const float MacroB = FMath::PerlinNoise2D(FVector2D(
                (SX + TerrainOffsetX + 2000.0f) * MacroScaleB,
                (SY + TerrainOffsetY + 2000.0f) * MacroScaleB));

            const float Detail = FMath::PerlinNoise2D(FVector2D(
                (SX + TerrainOffsetX - 4000.0f) * DetailScale,
                (SY + TerrainOffsetY - 4000.0f) * DetailScale));

            // Normalize Perlin output from [-1,1] to [0,1]
            const float Macro01A = (MacroA + 1.0f) * 0.5f;
            const float Macro01B = (MacroB + 1.0f) * 0.5f;
            const float Detail01 = (Detail + 1.0f) * 0.5f;

            // Slight island/continent framing: lowers edges a bit so coastlines form naturally
            const float DistToCenter = FVector2D::Distance(FVector2D(SX, SY), MapCenter);
            const float EdgeMask = FMath::Clamp(DistToCenter / MaxCenterDist, 0.0f, 1.0f);
            const float ContinentalFalloff = FMath::SmoothStep(0.15f, 1.0f, 1.0f - EdgeMask);

            float Elevation =
                Macro01A * 0.55f +
                Macro01B * 0.30f +
                Detail01 * 0.15f;

            Elevation = FMath::Lerp(Elevation * 0.65f, Elevation, ContinentalFalloff);

            Tile.Elevation = FMath::Clamp(Elevation, 0.0f, 1.0f);

            // --- Temperature ---
            const float Latitude01 = 1.0f - FMath::Abs((SY / float(GridHeight - 1)) * 2.0f - 1.0f);

            const float TempNoise = FMath::PerlinNoise2D(FVector2D(
                (SX + BiomeOffsetX) * TempScale,
                (SY + BiomeOffsetY) * TempScale));

            const float TempNoise01 = (TempNoise + 1.0f) * 0.5f;

            float Temperature =
                Latitude01 * 0.70f +
                TempNoise01 * 0.30f;

            // Higher elevations are colder
            Temperature -= Tile.Elevation * 0.25f;

            Tile.Temperature = FMath::Clamp(Temperature, 0.0f, 1.0f);

            // --- Rainfall ---
            const float RainNoiseA = FMath::PerlinNoise2D(FVector2D(
                (SX + BiomeOffsetX + 3000.0f) * RainScale,
                (SY + BiomeOffsetY + 3000.0f) * RainScale));

            const float RainNoiseB = FMath::PerlinNoise2D(FVector2D(
                (SX + BiomeOffsetX - 1500.0f) * (RainScale * 2.0f),
                (SY + BiomeOffsetY - 1500.0f) * (RainScale * 2.0f)));

            const float Rain01A = (RainNoiseA + 1.0f) * 0.5f;
            const float Rain01B = (RainNoiseB + 1.0f) * 0.5f;

            float Rainfall =
                Rain01A * 0.7f +
                Rain01B * 0.3f;

            // Very low elevation/coastal areas trend wetter
            Rainfall += (1.0f - Tile.Elevation) * 0.10f;

            Tile.Rainfall = FMath::Clamp(Rainfall, 0.0f, 1.0f);
        }
    }

    UE_LOG(LogTemp, Log, TEXT("[WorldGen] Step02 done"));
}

void UWorldGenPipeline::Step03_RunTectonics()
{
    UE_LOG(LogTemp, Log, TEXT("[WorldGen] Step03: Tectonics..."));

    MountainRanges.Reset();
    MountainProvinces.Reset();

    const FMountainGenerationSettings& Settings = CurrentConfig.MountainSettings;

    // Generate tectonic provinces and mountain ranges using the project RNG only.
    const int32 ProvinceCount = FMath::Clamp(
        RNGRef->NextInt(UWorldForgeRNG::BRANCH_TERRAIN, Settings.MinProvinceCount, Settings.MaxProvinceCount),
        1,
        64);

    MountainProvinces.Reserve(ProvinceCount);

    for (int32 ProvinceIdx = 0; ProvinceIdx < ProvinceCount; ++ProvinceIdx)
    {
        FMountainProvince Province;

        Province.Center = FVector2D(
            RNGRef->NextFloat(UWorldForgeRNG::BRANCH_TERRAIN) * float(GridWidth - 1),
            RNGRef->NextFloat(UWorldForgeRNG::BRANCH_TERRAIN) * float(GridHeight - 1));

        const float AngleDeg = RNGRef->NextFloat(UWorldForgeRNG::BRANCH_TERRAIN) * 360.0f;
        Province.Direction = FVector2D(
            FMath::Cos(FMath::DegreesToRadians(AngleDeg)),
            FMath::Sin(FMath::DegreesToRadians(AngleDeg))).GetSafeNormal();

        Province.SpreadRadius = FMath::Lerp(30.0f, 90.0f, RNGRef->NextFloat(UWorldForgeRNG::BRANCH_TERRAIN));
        Province.Strength = FMath::Lerp(0.8f, 1.3f, RNGRef->NextFloat(UWorldForgeRNG::BRANCH_TERRAIN));

        Province.RangeCount = FMath::Clamp(
            RNGRef->NextInt(UWorldForgeRNG::BRANCH_TERRAIN, Settings.MinRangesPerProvince, Settings.MaxRangesPerProvince),
            1,
            32);

        MountainProvinces.Add(Province);
    }

    for (const FMountainProvince& Province : MountainProvinces)
    {
        for (int32 RangeIdx = 0; RangeIdx < Province.RangeCount; ++RangeIdx)
        {
            const float DirAlpha = RNGRef->NextFloat(UWorldForgeRNG::BRANCH_TERRAIN);
            const float DirJitter = FMath::Lerp(
                -Settings.ProvinceDirectionJitterDegrees,
                Settings.ProvinceDirectionJitterDegrees,
                DirAlpha);

            const FVector2D FinalDir = Rotate2D(Province.Direction, DirJitter).GetSafeNormal();

            const float OffsetAngleDeg = RNGRef->NextFloat(UWorldForgeRNG::BRANCH_TERRAIN) * 360.0f;
            const float OffsetRadius = RNGRef->NextFloat(UWorldForgeRNG::BRANCH_TERRAIN) * Settings.StartOffsetJitterRadius;

            const FVector2D Offset(
                FMath::Cos(FMath::DegreesToRadians(OffsetAngleDeg)) * OffsetRadius,
                FMath::Sin(FMath::DegreesToRadians(OffsetAngleDeg)) * OffsetRadius);

            FMountainRange Range;
            Range.Start = Province.Center + Offset;
            Range.Start.X = FMath::Clamp(Range.Start.X, 0.0f, float(GridWidth - 1));
            Range.Start.Y = FMath::Clamp(Range.Start.Y, 0.0f, float(GridHeight - 1));

            Range.Direction = FinalDir;
            Range.Length = FMath::Lerp(Settings.MinRangeLength, Settings.MaxRangeLength, RNGRef->NextFloat(UWorldForgeRNG::BRANCH_TERRAIN));
            Range.Width = FMath::Lerp(Settings.MinRangeWidth, Settings.MaxRangeWidth, RNGRef->NextFloat(UWorldForgeRNG::BRANCH_TERRAIN));

            const float BaseHeight = FMath::Lerp(
                Settings.MinHeightMultiplier,
                Settings.MaxHeightMultiplier,
                RNGRef->NextFloat(UWorldForgeRNG::BRANCH_TERRAIN));

            Range.HeightMultiplier = BaseHeight * Province.Strength;

            Range.BasinOffset = Range.Width * FMath::Lerp(1.0f, 1.8f, RNGRef->NextFloat(UWorldForgeRNG::BRANCH_TERRAIN));
            Range.BasinWidth = Range.Width * FMath::Lerp(0.7f, 1.3f, RNGRef->NextFloat(UWorldForgeRNG::BRANCH_TERRAIN));
            Range.BasinStrength = Range.HeightMultiplier * Settings.BasinStrengthScale;

            MountainRanges.Add(Range);
        }
    }

    // Keep some broad tectonic variation, but let ridge ranges drive the visible structure.
    const float PlateStrength = 0.10f;
    const float RidgeNoiseStrength = 0.08f;
    const float ValleyNoiseStrength = 0.05f;
    const float PlateScale = 0.005f;
    const float RidgeScale = 0.02f;

    for (int32 Y = 0; Y < GridHeight; Y++)
    {
        for (int32 X = 0; X < GridWidth; X++)
        {
            const int32 Index = TileIndex(X, Y);
            FWorldTileData& Tile = WorldTiles[Index];

            float Elevation = Tile.Elevation;

            const float PlateNoise =
                FMath::PerlinNoise2D(FVector2D(X * PlateScale, Y * PlateScale));
            Elevation += PlateNoise * PlateStrength;

            const float RidgeNoise =
                FMath::Abs(FMath::PerlinNoise2D(FVector2D(X * RidgeScale, Y * RidgeScale)));
            Elevation += RidgeNoise * RidgeNoiseStrength;

            const float ValleyNoise =
                FMath::PerlinNoise2D(FVector2D((X + 1000) * RidgeScale, (Y + 1000) * RidgeScale));
            Elevation -= FMath::Abs(ValleyNoise) * ValleyNoiseStrength;

            const float MountainContribution = CalculateMountainContributionAtTile(
                FVector2D(float(X), float(Y)),
                MountainRanges,
                Settings.FalloffSharpness);

            Elevation += MountainContribution;
            Elevation = FMath::Clamp(Elevation, 0.0f, 1.0f);

            Tile.Elevation = Elevation;
        }
    }

    UE_LOG(LogTemp, Log,
        TEXT("[WorldGen] Step03 done. Provinces=%d Ranges=%d"),
        MountainProvinces.Num(),
        MountainRanges.Num());
}

void UWorldGenPipeline::Step04_AssignBiomes()
{
    UE_LOG(LogTemp, Log, TEXT("[WorldGen] Step04: Biomes..."));

    // Pre-cache the tags we'll use in the voxel profile overrides below so we
    // are not calling RequestGameplayTag inside a tight per-tile loop.
    const FGameplayTag MountainTag = FGameplayTag::RequestGameplayTag(FName(TEXT("WorldForge.Biome.Mountain")));
    const FGameplayTag CoastalTag = FGameplayTag::RequestGameplayTag(FName(TEXT("WorldForge.Biome.Coastal")));
    const FGameplayTag DesertTag = FGameplayTag::RequestGameplayTag(FName(TEXT("WorldForge.Biome.Desert")));
    const FGameplayTag DeepOceanTag = FGameplayTag::RequestGameplayTag(FName(TEXT("WorldForge.Biome.DeepOcean")));
    const FGameplayTag OceanTag = FGameplayTag::RequestGameplayTag(FName(TEXT("WorldForge.Biome.Ocean")));
    const FGameplayTag SeaTag = FGameplayTag::RequestGameplayTag(FName(TEXT("WorldForge.Biome.Sea")));
    const FGameplayTag ForestTag = FGameplayTag::RequestGameplayTag(FName(TEXT("WorldForge.Biome.Forest")));
    const FGameplayTag TundraTag = FGameplayTag::RequestGameplayTag(FName(TEXT("WorldForge.Biome.Tundra")));
    const FGameplayTag HillsTag = FGameplayTag::RequestGameplayTag(FName(TEXT("WorldForge.Biome.Hills")));
    const FGameplayTag PlainsTag = FGameplayTag::RequestGameplayTag(FName(TEXT("WorldForge.Biome.Plains")));

    for (FWorldTileData& Tile : WorldTiles)
    {
        // ------------------------------------------------------------------
        // BUG 3 FIX: The original Step04 collapsed every tile below elevation
        // 0.35 into "Coastal" (sand). That meant the map showed zero ocean
        // because the ocean/sea/deepocean tags were never emitted. The terrain
        // generator independently used SurfaceHeight <= SeaLevelVoxels to
        // render water, so the voxel world had oceans but the map never showed
        // blue — the two systems disagreed on what was water.
        //
        // Water biomes are now assigned first, in decreasing depth order, so
        // the map color code has real ocean/sea tags to match against. All
        // subsequent land biome rules only execute for tiles above the coastal
        // band (elevation >= 0.37).
        // ------------------------------------------------------------------

        // ---- Water / coastal biomes ----
        if (Tile.Elevation < 0.18f)
        {
            Tile.BiomeType = DeepOceanTag;
        }
        else if (Tile.Elevation < 0.26f)
        {
            Tile.BiomeType = OceanTag;
        }
        else if (Tile.Elevation < 0.32f)
        {
            Tile.BiomeType = SeaTag;
        }
        else if (Tile.Elevation < 0.37f)
        {
            Tile.BiomeType = CoastalTag;
        }

        // ---- Land biomes ----
        else if (Tile.Elevation > 0.80f)
        {
            Tile.BiomeType = MountainTag;
        }
        else if (Tile.Elevation > 0.65f && Tile.Rainfall > 0.5f)
        {
            Tile.BiomeType = ForestTag;
        }
        else if (Tile.Elevation > 0.65f)
        {
            Tile.BiomeType = TundraTag;
        }
        else if (Tile.Elevation > 0.50f)
        {
            Tile.BiomeType = HillsTag;
        }
        else if (Tile.Elevation > 0.37f && Tile.Temperature > 0.7f)
        {
            Tile.BiomeType = DesertTag;
        }
        else
        {
            // Low-to-mid land: forest if wet, plains if dry
            Tile.BiomeType = (Tile.Rainfall > 0.50f) ? ForestTag : PlainsTag;
        }

        // ------------------------------------------------------------------
        // Voxel profile -- bSmoothSDF ALWAYS true
        // ------------------------------------------------------------------
        Tile.VoxelProfile.bSmoothSDF = true;

        // Water tiles: keep the profile flat and cheap. The generator uses
        // surface height relative to SeaLevelVoxels to render the seafloor,
        // so a minimal profile is correct here.
        const bool bIsWaterTile =
            Tile.BiomeType.MatchesTag(DeepOceanTag) ||
            Tile.BiomeType.MatchesTag(OceanTag) ||
            Tile.BiomeType.MatchesTag(SeaTag);

        if (bIsWaterTile)
        {
            Tile.VoxelProfile.NoiseAmplitude = 8.0f;
            Tile.VoxelProfile.NoiseFrequency = 0.005f;
            Tile.VoxelProfile.OctaveCount = 1;
            Tile.VoxelProfile.bEnableCaves = false;
        }
        else
        {
            // Land and coastal tiles: scale profile to elevation.
            // Higher elevation = taller, rougher, more octaves.
            const float ElevationAlpha = FMath::Clamp(Tile.Elevation, 0.0f, 1.0f);

            Tile.VoxelProfile.NoiseAmplitude = FMath::Lerp(20.0f, 220.0f, ElevationAlpha);
            Tile.VoxelProfile.NoiseFrequency = FMath::Lerp(0.008f, 0.028f, ElevationAlpha);
            Tile.VoxelProfile.OctaveCount = (ElevationAlpha > 0.75f) ? 5 : ((ElevationAlpha > 0.45f) ? 4 : 3);
            Tile.VoxelProfile.bEnableCaves = (Tile.Elevation > 0.55f);

            // Mountain override: ensure peaks always have maximum profile strength.
            if (Tile.BiomeType.MatchesTag(MountainTag))
            {
                Tile.VoxelProfile.NoiseAmplitude = FMath::Max(Tile.VoxelProfile.NoiseAmplitude, 260.0f);
                Tile.VoxelProfile.NoiseFrequency = FMath::Max(Tile.VoxelProfile.NoiseFrequency, 0.030f);
                Tile.VoxelProfile.OctaveCount = FMath::Max(Tile.VoxelProfile.OctaveCount, 5);
                Tile.VoxelProfile.bEnableCaves = true;
            }
            // Coastal band: keep very flat so the shoreline doesn't spike above sea level.
            else if (Tile.BiomeType.MatchesTag(CoastalTag))
            {
                Tile.VoxelProfile.NoiseAmplitude = FMath::Min(Tile.VoxelProfile.NoiseAmplitude, 28.0f);
                Tile.VoxelProfile.NoiseFrequency = FMath::Min(Tile.VoxelProfile.NoiseFrequency, 0.010f);
                Tile.VoxelProfile.OctaveCount = 2;
                Tile.VoxelProfile.bEnableCaves = false;
            }
            // Desert: gentle dunes, no caves.
            else if (Tile.BiomeType.MatchesTag(DesertTag))
            {
                Tile.VoxelProfile.NoiseAmplitude = FMath::Min(Tile.VoxelProfile.NoiseAmplitude, 65.0f);
                Tile.VoxelProfile.NoiseFrequency = FMath::Min(Tile.VoxelProfile.NoiseFrequency, 0.014f);
                Tile.VoxelProfile.OctaveCount = 3;
            }
        }
    }

    UE_LOG(LogTemp, Log, TEXT("[WorldGen] Step04 done"));
}

void UWorldGenPipeline::Step05_InitVoxelChunks()
{
    UE_LOG(LogTemp, Log, TEXT("[WorldGen] Step05: Init voxel chunks..."));

    if (!WorldRef)
    {
        UE_LOG(LogTemp, Warning, TEXT("[WorldGen] Step05 failed: WorldRef is null."));
        return;
    }

    UVoxelWorldManager* VoxelMgr = WorldRef->GetSubsystem<UVoxelWorldManager>();
    if (!VoxelMgr)
    {
        UE_LOG(LogTemp, Warning, TEXT("[WorldGen] Step05 failed: UVoxelWorldManager not found."));
        return;
    }

    const bool bAccepted = VoxelMgr->GenerateTerrainFromTiles(
        WorldTiles,
        GridWidth,
        GridHeight,
        CurrentConfig.TerrainMode,
        CurrentConfig.BlockHeightStep);

    if (!bAccepted)
    {
        UE_LOG(LogTemp, Warning, TEXT("[WorldGen] Step05: terrain request was not accepted."));
        return;
    }

    UE_LOG(
        LogTemp,
        Log,
        TEXT("[WorldGen] Step05 done. TerrainMode=%s BlockHeightStep=%d"),
        CurrentConfig.TerrainMode == ETerrainMode::Blocky ? TEXT("Blocky") : TEXT("Smooth"),
        CurrentConfig.BlockHeightStep
    );
}

void UWorldGenPipeline::Step06_PCGDecorationPass()
{
    UE_LOG(LogTemp, Log, TEXT("[WorldGen] Step06: Decoration hook..."));

    HandlePCGDecorationPass(WorldTiles, GridWidth, GridHeight);

    UE_LOG(LogTemp, Log, TEXT("[WorldGen] Step06 done"));
}

void UWorldGenPipeline::Step07_ApplyWorldDriver()
{
    UE_LOG(LogTemp, Log, TEXT("[WorldGen] Step07 -- TODO"));
}

void UWorldGenPipeline::Step08_SeedResources()
{
    UE_LOG(LogTemp, Log, TEXT("[WorldGen] Step08: Seeding resources..."));

    const FGameplayTag StoneTag = FGameplayTag::RequestGameplayTag(FName(TEXT("WorldForge.Resource.Stone")));
    const FGameplayTag WoodTag = FGameplayTag::RequestGameplayTag(FName(TEXT("WorldForge.Resource.Wood")));
    const FGameplayTag OreTag = FGameplayTag::RequestGameplayTag(FName(TEXT("WorldForge.Resource.Ore")));

    const FGameplayTag MountainTag = FGameplayTag::RequestGameplayTag(FName(TEXT("WorldForge.Biome.Mountain")));
    const FGameplayTag ForestTag = FGameplayTag::RequestGameplayTag(FName(TEXT("WorldForge.Biome.Forest")));
    const FGameplayTag DesertTag = FGameplayTag::RequestGameplayTag(FName(TEXT("WorldForge.Biome.Desert")));

    for (FWorldTileData& Tile : WorldTiles)
    {
        Tile.ResourceTags.Reset();

        // -----------------------------
        // Mountain: Stone + Ore
        // -----------------------------
        if (Tile.BiomeType.MatchesTag(MountainTag))
        {
            Tile.ResourceTags.Add(StoneTag);

            if (RNGRef->NextFloat(UWorldForgeRNG::BRANCH_RESOURCES) > 0.5f)
            {
                Tile.ResourceTags.Add(OreTag);
            }
        }

        // -----------------------------
        // Forest: Wood
        // -----------------------------
        else if (Tile.BiomeType.MatchesTag(ForestTag))
        {
            Tile.ResourceTags.Add(WoodTag);

            // small chance of stone in forest
            if (RNGRef->NextFloat(UWorldForgeRNG::BRANCH_RESOURCES) > 0.8f)
            {
                Tile.ResourceTags.Add(StoneTag);
            }
        }

        // -----------------------------
        // Desert: mostly empty
        // -----------------------------
        else if (Tile.BiomeType.MatchesTag(DesertTag))
        {
            // very low chance of stone
            if (RNGRef->NextFloat(UWorldForgeRNG::BRANCH_RESOURCES) > 0.9f)
            {
                Tile.ResourceTags.Add(StoneTag);
            }
        }

        // -----------------------------
        // General fallback (mid terrain)
        // -----------------------------
        else
        {
            if (Tile.Elevation > 0.4f &&
                RNGRef->NextFloat(UWorldForgeRNG::BRANCH_RESOURCES) > 0.7f)
            {
                Tile.ResourceTags.Add(StoneTag);
            }
        }
    }

    UE_LOG(LogTemp, Log, TEXT("[WorldGen] Step08 done"));
}

// Steps 12, 14, 15, 16 remain stubs for now
void UWorldGenPipeline::Step12_GenerateCosmicRoster()
{
    UE_LOG(LogTemp, Log, TEXT("[WorldGen] Step12 -- TODO"));
}

void UWorldGenPipeline::Step14_AssignWorldTraits()
{
    UE_LOG(LogTemp, Log, TEXT("[WorldGen] Step14 -- TODO"));
}

void UWorldGenPipeline::Step15_RecordFinalState()
{
    UE_LOG(LogTemp, Log, TEXT("[WorldGen] Step15 -- TODO"));
}

void UWorldGenPipeline::Step16_FinalizeWorldMap()
{
    UE_LOG(LogTemp, Log, TEXT("[WorldGen] Step16 -- TODO"));
}

void UWorldGenPipeline::Step09_PlaceCivilizations()
{
    UE_LOG(LogTemp, Log, TEXT("[WorldGen] Step09: Placing civilizations..."));

    if (!RNGRef)
    {
        return;
    }

    UCivilizationGenerator* CivGen = NewObject<UCivilizationGenerator>(this);
    Civilizations = CivGen->GenerateCivilizations(
        CurrentConfig.StartingCivCount, WorldTiles, GridWidth, RNGRef);

    UE_LOG(LogTemp, Log, TEXT("[WorldGen] Step09: %d civs placed"), Civilizations.Num());
}

void UWorldGenPipeline::Step10_GenerateCulturalDNA()
{
    UE_LOG(LogTemp, Log, TEXT("[WorldGen] Step10: Cultural DNA..."));

    if (!RNGRef)
    {
        return;
    }

    UCivilizationGenerator* CivGen = NewObject<UCivilizationGenerator>(this);
    CivGen->GenerateCulturalDNA(Civilizations, WorldTiles, RNGRef);

    UE_LOG(LogTemp, Log, TEXT("[WorldGen] Step10: Cultural DNA done for %d civs"), Civilizations.Num());
}

void UWorldGenPipeline::Step11_GenerateEconomyLayer()
{
    UE_LOG(LogTemp, Log, TEXT("[WorldGen] Step11: Economy layer..."));

    if (!WorldRef)
    {
        UE_LOG(LogTemp, Warning, TEXT("[WorldGen] Step11: WorldRef null"));
        return;
    }

    if (UWorldEconomySimulation* Econ = WorldRef->GetSubsystem<UWorldEconomySimulation>())
    {
        Econ->GenerateWorldEconomy(Civilizations, WorldTiles, Currencies, RNGRef);
    }
    else
    {
        UE_LOG(LogTemp, Warning, TEXT("[WorldGen] Step11: UWorldEconomySimulation not found"));
    }

    UE_LOG(LogTemp, Log, TEXT("[WorldGen] Step11: %d currencies"), Currencies.Num());
}

void UWorldGenPipeline::Step13_RunPreHistory()
{
    UE_LOG(LogTemp, Log, TEXT("[WorldGen] Step13: Pre-history..."));

    if (!RNGRef)
    {
        return;
    }

    FHistoricalSimConfig SimCfg;
    SimCfg.TotalYears = CurrentConfig.PreHistoryYears;
    SimCfg.WarFrequency = CurrentConfig.WarFrequency;
    SimCfg.DisasterFrequency = CurrentConfig.DisasterFrequency;
    SimCfg.EconomicComplexity = CurrentConfig.EconomicComplexity;

    UHistoricalSimulation* HistSim = NewObject<UHistoricalSimulation>(this);
    HistSim->RunSimulation(SimCfg, Civilizations, WorldTiles, Currencies, HistoryLog, RNGRef);

    UE_LOG(LogTemp, Log, TEXT("[WorldGen] Step13: %d events"), HistoryLog.Num());

    {
        FWorldHistoryContext Context;
        Context.RNG = RNGRef;
        Context.CurrentYear = CurrentConfig.PreHistoryYears;

        FWorldHistoryGenerator Generator;
        Generator.Run(Context);

        const int32 NameCount = FMath::Min(Civilizations.Num(), Context.GeneratedNames.Num());

        TSet<FString> UsedNames;

        for (int32 Index = 0; Index < NameCount; ++Index)
        {
            FString RawName = Context.GeneratedNames[Index];

            RawName = CleanNameArtifacts(RawName);

            if (RawName.Len() > 0)
            {
                RawName[0] = FChar::ToUpper(RawName[0]);
            }

            FString FinalName = RawName;

            int32 Suffix = 1;
            while (UsedNames.Contains(FinalName))
            {
                FinalName = FString::Printf(TEXT("%s %d"), *RawName, Suffix);
                ++Suffix;
            }

            UsedNames.Add(FinalName);

            FText NameText = FText::FromString(FinalName);
            Civilizations[Index].Name = NameText.ToString();

            UE_LOG(
                LogTemp,
                Log,
                TEXT("[WorldHistory] Assigned Civilization %d Name: %s"),
                Civilizations[Index].CivID,
                *Civilizations[Index].Name);
        }

        if (Context.GeneratedFigures.Num() == Civilizations.Num())
        {
            for (int32 Index = 0; Index < Civilizations.Num(); ++Index)
            {
                Civilizations[Index].LegendaryFigure = Context.GeneratedFigures[Index];

                UE_LOG(
                    LogTemp,
                    Log,
                    TEXT("[WorldHistory] Civilization %d Figure Stored As: %s"),
                    Civilizations[Index].CivID,
                    *Civilizations[Index].LegendaryFigure);
            }
        }

        for (int32 Index = 0; Index < NameCount; ++Index)
        {
            if (Context.RaceOrigins.IsValidIndex(Index))
            {
                Civilizations[Index].RaceOrigin = Context.RaceOrigins[Index];

                UE_LOG(
                    LogTemp,
                    Log,
                    TEXT("[WorldHistory] Civilization %d Origin Stored As: %s"),
                    Civilizations[Index].CivID,
                    *Civilizations[Index].RaceOrigin);
            }
        }
    }
}