#include "WorldForgeFullMapWidget.h"

#include "Components/Image.h"
#include "Components/Border.h"
#include "Components/TextBlock.h"
#include "Components/Button.h"
#include "Components/CanvasPanelSlot.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "GameFramework/PlayerController.h"
#include "Input/Reply.h"
#include "InputCoreTypes.h"
#include "WorldMapSubsystem.h"
#include "ColonyManager.h"
#include "../Voxel/VoxelWorldManager.h"

namespace
{
    static UTexture2D* GetPreferredFullMapTexture(UWorldMapSubsystem* MapSubsystem, bool bPreferDetailedMap)
    {
        if (!MapSubsystem)
        {
            return nullptr;
        }

        if (bPreferDetailedMap)
        {
            if (UTexture2D* DetailedTexture = MapSubsystem->GetOrCreateDetailedMapTexture())
            {
                return DetailedTexture;
            }
        }

        if (UTexture2D* BiomeTexture = MapSubsystem->GetOrCreateMapTexture())
        {
            return BiomeTexture;
        }

        if (!bPreferDetailedMap)
        {
            return MapSubsystem->GetOrCreateDetailedMapTexture();
        }

        return nullptr;
    }
}

// ============================================================
void UWorldForgeFullMapWidget::NativeConstruct()
{
    Super::NativeConstruct();

    MapSubsystem = GetWorld() ? GetWorld()->GetSubsystem<UWorldMapSubsystem>() : nullptr;
    CachedPlayerController = GetWorld() ? GetWorld()->GetFirstPlayerController() : nullptr;

    UE_LOG(LogTemp, Warning,
        TEXT("[FullMapWidget] Constructed | IMG_Map=%s BRD_SelectedCell=%s TXT_SelectedCell=%s BTN_Confirm=%s BTN_Close=%s"),
        IMG_Map ? TEXT("OK") : TEXT("NULL"),
        BRD_SelectedCell ? TEXT("OK") : TEXT("NULL"),
        TXT_SelectedCell ? TEXT("OK") : TEXT("NULL"),
        BTN_Confirm ? TEXT("OK") : TEXT("NULL"),
        BTN_Close ? TEXT("OK") : TEXT("NULL"));

    if (IMG_Map && MapSubsystem)
    {
        // True biome map by default.
        // Set this to true later only if you explicitly want the detailed terrain-debug map.
        constexpr bool bPreferDetailedMap = false;

        if (UTexture2D* MapTexture = GetPreferredFullMapTexture(MapSubsystem, bPreferDetailedMap))
        {
            IMG_Map->SetBrushFromTexture(MapTexture, true);
        }
    }

    if (BRD_SelectedCell)
    {
        BRD_SelectedCell->SetRenderOpacity(0.0f);
    }

    if (BTN_Confirm)
    {
        BTN_Confirm->OnClicked.RemoveDynamic(this, &UWorldForgeFullMapWidget::HandleConfirmClicked);
        BTN_Confirm->OnClicked.AddDynamic(this, &UWorldForgeFullMapWidget::HandleConfirmClicked);
    }

    if (BTN_Close)
    {
        BTN_Close->OnClicked.RemoveDynamic(this, &UWorldForgeFullMapWidget::HandleCloseClicked);
        BTN_Close->OnClicked.AddDynamic(this, &UWorldForgeFullMapWidget::HandleCloseClicked);
    }

    bHasValidSelection = false;
    SelectedTileX = INDEX_NONE;
    SelectedTileY = INDEX_NONE;
    SelectedTileIndex = INDEX_NONE;

    ViewCenterX = 0.5f;
    ViewCenterY = 0.5f;
    Zoom = 1.0f;

    if (IMG_Map)
    {
        IMG_Map->SetRenderTransformPivot(FVector2D(0.5f, 0.5f));
        ApplyMapTransform();
    }

    EnsureValidInitialSelection();
    UpdateSelectionVisual();
    UpdateSelectionText();

    SetIsFocusable(true);
    EnterMapSelectionInputMode();
    SetKeyboardFocus();
}

// ============================================================
void UWorldForgeFullMapWidget::NativeDestruct()
{
    bPanUp = false;
    bPanDown = false;
    bPanLeft = false;
    bPanRight = false;
    bPanFast = false;

    RestoreGameInputMode();
    Super::NativeDestruct();
}

// ============================================================
void UWorldForgeFullMapWidget::NativeTick(const FGeometry& MyGeometry, float InDeltaTime)
{
    Super::NativeTick(MyGeometry, InDeltaTime);

    float PanX = 0.0f;
    float PanY = 0.0f;

    if (bPanRight) PanX += 1.0f;
    if (bPanLeft)  PanX -= 1.0f;
    if (bPanDown)  PanY += 1.0f;
    if (bPanUp)    PanY -= 1.0f;

    if (PanX != 0.0f || PanY != 0.0f)
    {
        const float Speed = PanSpeed
            * (bPanFast ? FastPanMultiplier : 1.0f)
            * InDeltaTime
            / FMath::Max(Zoom, 0.001f);

        ViewCenterX += PanX * Speed;
        ViewCenterY += PanY * Speed;

        ClampViewCenter();
        ApplyMapTransform();
        UpdateSelectionVisual();
    }
}

// ============================================================
FReply UWorldForgeFullMapWidget::NativeOnMouseButtonDown(
    const FGeometry& InGeometry,
    const FPointerEvent& InMouseEvent)
{
    if (!MapSubsystem || !IMG_Map)
    {
        return FReply::Unhandled();
    }

    const FGeometry MapGeometry = IMG_Map->GetCachedGeometry();
    const FVector2D LocalPos = MapGeometry.AbsoluteToLocal(InMouseEvent.GetScreenSpacePosition());
    const FVector2D MapSize = MapGeometry.GetLocalSize();

    if (MapSize.X <= 0.0f || MapSize.Y <= 0.0f)
    {
        return FReply::Unhandled();
    }

    const bool bInsideMap =
        LocalPos.X >= 0.0f && LocalPos.X <= MapSize.X &&
        LocalPos.Y >= 0.0f && LocalPos.Y <= MapSize.Y;

    if (!bInsideMap)
    {
        return FReply::Unhandled();
    }

    const FVector2D WidgetUV(
        LocalPos.X / MapSize.X,
        LocalPos.Y / MapSize.Y);

    const FVector2D UV = WidgetUVToWorldUV(WidgetUV);

    FIntPoint ResolvedTileXY(INDEX_NONE, INDEX_NONE);
    FIntPoint SelectedVoxelXY = FIntPoint::ZeroValue;
    int32 ResolvedIndex = INDEX_NONE;

    if (!MapSubsystem->WorldUVToBestSpawnTile(UV, ResolvedTileXY, ResolvedIndex, SelectedVoxelXY))
    {
        bHasValidSelection = false;
        SelectedTileX = INDEX_NONE;
        SelectedTileY = INDEX_NONE;
        SelectedTileIndex = INDEX_NONE;

        if (BRD_SelectedCell)
        {
            BRD_SelectedCell->SetRenderOpacity(0.0f);
        }

        UpdateSelectionText();
        return FReply::Handled();
    }

    SelectedTileX = ResolvedTileXY.X;
    SelectedTileY = ResolvedTileXY.Y;
    SelectedTileIndex = ResolvedIndex;
    bHasValidSelection = true;

    UE_LOG(LogTemp, Log,
        TEXT("[FullMap] Selected tile: X=%d Y=%d Index=%d WorldUV=(%.3f,%.3f) Voxel=(%d,%d) Zoom=%.2f"),
        SelectedTileX,
        SelectedTileY,
        SelectedTileIndex,
        UV.X,
        UV.Y,
        SelectedVoxelXY.X,
        SelectedVoxelXY.Y,
        Zoom);

    UpdateSelectionVisual();
    UpdateSelectionText();
    return FReply::Handled();
}

// ============================================================
FReply UWorldForgeFullMapWidget::NativeOnMouseWheel(
    const FGeometry& InGeometry,
    const FPointerEvent& InMouseEvent)
{
    const float Delta = InMouseEvent.GetWheelDelta();
    Zoom = FMath::Clamp(Zoom + Delta * ZoomStep, MinZoom, MaxZoom);

    ClampViewCenter();
    ApplyMapTransform();
    UpdateSelectionVisual();

    return FReply::Handled();
}

// ============================================================
FReply UWorldForgeFullMapWidget::NativeOnKeyDown(
    const FGeometry& InGeometry,
    const FKeyEvent& InKeyEvent)
{
    if (!MapSubsystem)
    {
        return FReply::Unhandled();
    }

    const FKey Key = InKeyEvent.GetKey();
    const bool bFastMove = InKeyEvent.IsShiftDown();

    if (Key == EKeys::W) { bPanUp = true; bPanFast = bFastMove; return FReply::Handled(); }
    if (Key == EKeys::S) { bPanDown = true; bPanFast = bFastMove; return FReply::Handled(); }
    if (Key == EKeys::A) { bPanLeft = true; bPanFast = bFastMove; return FReply::Handled(); }
    if (Key == EKeys::D) { bPanRight = true; bPanFast = bFastMove; return FReply::Handled(); }

    if (Key == EKeys::Up) { MoveSelectionBy(0, -1, bFastMove); return FReply::Handled(); }
    if (Key == EKeys::Down) { MoveSelectionBy(0, 1, bFastMove); return FReply::Handled(); }
    if (Key == EKeys::Left) { MoveSelectionBy(-1, 0, bFastMove); return FReply::Handled(); }
    if (Key == EKeys::Right) { MoveSelectionBy(1, 0, bFastMove); return FReply::Handled(); }

    if (Key == EKeys::Enter) { HandleConfirmClicked(); return FReply::Handled(); }
    if (Key == EKeys::Escape) { HandleCloseClicked(); return FReply::Handled(); }

    return Super::NativeOnKeyDown(InGeometry, InKeyEvent);
}

// ============================================================
FReply UWorldForgeFullMapWidget::NativeOnKeyUp(
    const FGeometry& InGeometry,
    const FKeyEvent& InKeyEvent)
{
    const FKey Key = InKeyEvent.GetKey();

    if (Key == EKeys::W) bPanUp = false;
    if (Key == EKeys::S) bPanDown = false;
    if (Key == EKeys::A) bPanLeft = false;
    if (Key == EKeys::D) bPanRight = false;

    if (!bPanUp && !bPanDown && !bPanLeft && !bPanRight)
    {
        bPanFast = false;
    }

    return Super::NativeOnKeyUp(InGeometry, InKeyEvent);
}

// ============================================================
void UWorldForgeFullMapWidget::HandleConfirmClicked()
{
    if (!bHasValidSelection)
    {
        UE_LOG(LogTemp, Warning, TEXT("[FullMap] Confirm clicked with no valid tile selected."));
        return;
    }

    FIntPoint FinalCell(SelectedTileX, SelectedTileY);

    if (UWorld* World = GetWorld())
    {
        if (UVoxelWorldManager* VoxelMgr = World->GetSubsystem<UVoxelWorldManager>())
        {
            if (!VoxelMgr->IsSpawnableTerrainCell(FinalCell))
            {
                FIntPoint NearestSpawnable = FinalCell;

                if (VoxelMgr->FindNearestSpawnableTerrainCell(FinalCell, NearestSpawnable, 48))
                {
                    UE_LOG(LogTemp, Warning,
                        TEXT("[FullMap] Confirm: snapping (%d,%d) to nearest spawnable (%d,%d)."),
                        FinalCell.X, FinalCell.Y,
                        NearestSpawnable.X, NearestSpawnable.Y);

                    FinalCell = NearestSpawnable;
                }
                else
                {
                    UE_LOG(LogTemp, Error,
                        TEXT("[FullMap] Confirm failed: (%d,%d) non-spawnable, no fallback found."),
                        FinalCell.X, FinalCell.Y);
                    return;
                }
            }
        }
    }

    int32 FinalIndex = INDEX_NONE;
    if (!MapSubsystem || !MapSubsystem->TileXYToIndex(FinalCell.X, FinalCell.Y, FinalIndex))
    {
        UE_LOG(LogTemp, Error, TEXT("[FullMap] Confirm failed: unable to resolve final tile index."));
        return;
    }

    SelectedTileX = FinalCell.X;
    SelectedTileY = FinalCell.Y;
    SelectedTileIndex = FinalIndex;

    UE_LOG(LogTemp, Log,
        TEXT("[FullMap] Confirmed: X=%d Y=%d Index=%d"),
        SelectedTileX, SelectedTileY, SelectedTileIndex);

    if (MapSubsystem)
    {
        MapSubsystem->SetSelectedStartTile(SelectedTileX, SelectedTileY, SelectedTileIndex);
        MapSubsystem->RevealTile(SelectedTileIndex, EKnowledgeLevel::Surveyed, 1.0f);
        MapSubsystem->MarkMapTextureDirty();
        MapSubsystem->MarkDetailedMapTextureDirty();

        if (IMG_Map)
        {
            // Keep true biome map as the visible/default map after confirm as well.
            constexpr bool bPreferDetailedMap = false;

            if (UTexture2D* MapTexture = GetPreferredFullMapTexture(MapSubsystem, bPreferDetailedMap))
            {
                IMG_Map->SetBrushFromTexture(MapTexture, true);
            }
        }
    }

    if (UWorld* World = GetWorld())
    {
        for (TActorIterator<AColonyManager> It(World); It; ++It)
        {
            if (AColonyManager* CM = *It)
            {
                if (IsValid(CM))
                {
                    CM->BeginBootstrapNow();
                    break;
                }
            }
        }
    }

    RemoveFromParent();
}

// ============================================================
void UWorldForgeFullMapWidget::HandleCloseClicked()
{
    RemoveFromParent();
}

// ============================================================
void UWorldForgeFullMapWidget::UpdateSelectionVisual()
{
    if (!BRD_SelectedCell || !IMG_Map || !MapSubsystem || !bHasValidSelection)
    {
        return;
    }

    const FVector2D MapSize = IMG_Map->GetCachedGeometry().GetLocalSize();
    if (MapSize.X <= 0.0f || MapSize.Y <= 0.0f)
    {
        return;
    }

    const int32 GridWidth = MapSubsystem->GetGridWidth();
    const int32 GridHeight = MapSubsystem->GetGridHeight();
    if (GridWidth <= 0 || GridHeight <= 0)
    {
        return;
    }

    const float TileU = (static_cast<float>(SelectedTileX) + 0.5f)
        / static_cast<float>(GridWidth);
    const float TileV = (static_cast<float>(SelectedTileY) + 0.5f)
        / static_cast<float>(GridHeight);

    const float ScreenU = 0.5f + Zoom * (TileU - ViewCenterX);
    const float ScreenV = 0.5f + Zoom * (TileV - ViewCenterY);

    if (ScreenU < 0.0f || ScreenU > 1.0f || ScreenV < 0.0f || ScreenV > 1.0f)
    {
        BRD_SelectedCell->SetRenderOpacity(0.0f);
        return;
    }

    const float CellW = MapSize.X * Zoom / static_cast<float>(GridWidth);
    const float CellH = MapSize.Y * Zoom / static_cast<float>(GridHeight);

    const FVector2D Position(
        ScreenU * MapSize.X - CellW * 0.5f,
        ScreenV * MapSize.Y - CellH * 0.5f);

    if (UCanvasPanelSlot* CanvasSlot = Cast<UCanvasPanelSlot>(BRD_SelectedCell->Slot))
    {
        CanvasSlot->SetPosition(Position);
        CanvasSlot->SetSize(FVector2D(CellW, CellH));
    }

    BRD_SelectedCell->SetRenderOpacity(1.0f);
}

// ============================================================
void UWorldForgeFullMapWidget::UpdateSelectionText()
{
    if (!TXT_SelectedCell)
    {
        return;
    }

    if (!bHasValidSelection)
    {
        TXT_SelectedCell->SetText(FText::FromString(TEXT("No Tile Selected")));
        return;
    }

    const FString Str = FString::Printf(
        TEXT("Tile X=%d Y=%d Index=%d  |  WASD pan  |  Shift=faster  |  Scroll=zoom  |  Arrows=move cursor  |  Enter confirm  |  Esc close"),
        SelectedTileX,
        SelectedTileY,
        SelectedTileIndex);

    TXT_SelectedCell->SetText(FText::FromString(Str));
}

// ============================================================
void UWorldForgeFullMapWidget::ApplyMapTransform()
{
    if (!IMG_Map)
    {
        return;
    }

    const FVector2D MapSize = IMG_Map->GetCachedGeometry().GetLocalSize();

    FWidgetTransform T;
    T.Scale = FVector2D(Zoom, Zoom);
    T.Translation = FVector2D(
        -(ViewCenterX - 0.5f) * MapSize.X * Zoom,
        -(ViewCenterY - 0.5f) * MapSize.Y * Zoom);

    IMG_Map->SetRenderTransform(T);
}

// ============================================================
FVector2D UWorldForgeFullMapWidget::WidgetUVToWorldUV(const FVector2D& WidgetUV) const
{
    const float VisW = 1.0f / FMath::Max(Zoom, 0.001f);
    const float MinU = ViewCenterX - VisW * 0.5f;
    const float MinV = ViewCenterY - VisW * 0.5f;

    return FVector2D(
        FMath::Clamp(MinU + WidgetUV.X * VisW, 0.0f, 1.0f),
        FMath::Clamp(MinV + WidgetUV.Y * VisW, 0.0f, 1.0f));
}

// ============================================================
void UWorldForgeFullMapWidget::ClampViewCenter()
{
    const float Half = 0.5f / FMath::Max(Zoom, 0.001f);
    ViewCenterX = FMath::Clamp(ViewCenterX, Half, 1.0f - Half);
    ViewCenterY = FMath::Clamp(ViewCenterY, Half, 1.0f - Half);
}

// ============================================================
void UWorldForgeFullMapWidget::EnterMapSelectionInputMode()
{
    if (!CachedPlayerController)
    {
        return;
    }

    FInputModeUIOnly InputMode;
    InputMode.SetWidgetToFocus(TakeWidget());
    InputMode.SetLockMouseToViewportBehavior(EMouseLockMode::DoNotLock);

    CachedPlayerController->SetInputMode(InputMode);
    CachedPlayerController->bShowMouseCursor = true;
    CachedPlayerController->SetIgnoreLookInput(true);
    CachedPlayerController->SetIgnoreMoveInput(true);

    bInputLockedToUI = true;

    UE_LOG(LogTemp, Log, TEXT("[FullMapWidget] Entered UI-only input mode."));
}

// ============================================================
void UWorldForgeFullMapWidget::RestoreGameInputMode()
{
    if (!bInputLockedToUI || !CachedPlayerController)
    {
        return;
    }

    FInputModeGameAndUI InputMode;
    InputMode.SetLockMouseToViewportBehavior(EMouseLockMode::LockOnCapture);
    InputMode.SetHideCursorDuringCapture(false);

    CachedPlayerController->SetInputMode(InputMode);
    CachedPlayerController->bShowMouseCursor = true;
    CachedPlayerController->SetIgnoreLookInput(false);
    CachedPlayerController->SetIgnoreMoveInput(false);

    bInputLockedToUI = false;

    UE_LOG(LogTemp, Log, TEXT("[FullMapWidget] Restored game-and-ui input mode."));
}

// ============================================================
void UWorldForgeFullMapWidget::MoveSelectionBy(int32 DeltaX, int32 DeltaY, bool bFastMove)
{
    if (!MapSubsystem)
    {
        return;
    }

    EnsureValidInitialSelection();

    if (!bHasValidSelection)
    {
        return;
    }

    const int32 Step = bFastMove
        ? FMath::Max(1, KeyboardMoveStepFast)
        : FMath::Max(1, KeyboardMoveStep);

    SelectedTileX += DeltaX * Step;
    SelectedTileY += DeltaY * Step;

    ClampSelectionToMap();

    int32 TileIndex = INDEX_NONE;
    if (MapSubsystem->TileXYToIndex(SelectedTileX, SelectedTileY, TileIndex))
    {
        SelectedTileIndex = TileIndex;
        bHasValidSelection = true;

        const float TileU = (static_cast<float>(SelectedTileX) + 0.5f)
            / static_cast<float>(MapSubsystem->GetGridWidth());
        const float TileV = (static_cast<float>(SelectedTileY) + 0.5f)
            / static_cast<float>(MapSubsystem->GetGridHeight());

        const float VisHalf = 0.5f / FMath::Max(Zoom, 0.001f);
        const bool bOffscreenX = (TileU < ViewCenterX - VisHalf) || (TileU > ViewCenterX + VisHalf);
        const bool bOffscreenY = (TileV < ViewCenterY - VisHalf) || (TileV > ViewCenterY + VisHalf);

        if (bOffscreenX || bOffscreenY)
        {
            ViewCenterX = TileU;
            ViewCenterY = TileV;
            ClampViewCenter();
            ApplyMapTransform();
        }

        UE_LOG(LogTemp, Log,
            TEXT("[FullMap] Arrow moved selection: X=%d Y=%d Index=%d Step=%d"),
            SelectedTileX, SelectedTileY, SelectedTileIndex, Step);
    }

    UpdateSelectionVisual();
    UpdateSelectionText();
}

// ============================================================
void UWorldForgeFullMapWidget::ClampSelectionToMap()
{
    if (!MapSubsystem)
    {
        return;
    }

    SelectedTileX = FMath::Clamp(SelectedTileX, 0, FMath::Max(0, MapSubsystem->GetGridWidth() - 1));
    SelectedTileY = FMath::Clamp(SelectedTileY, 0, FMath::Max(0, MapSubsystem->GetGridHeight() - 1));
}

// ============================================================
void UWorldForgeFullMapWidget::EnsureValidInitialSelection()
{
    if (!MapSubsystem || bHasValidSelection)
    {
        return;
    }

    int32 ExistingX = INDEX_NONE;
    int32 ExistingY = INDEX_NONE;
    int32 ExistingIndex = INDEX_NONE;

    if (MapSubsystem->GetSelectedStartTile(ExistingX, ExistingY, ExistingIndex))
    {
        SelectedTileX = ExistingX;
        SelectedTileY = ExistingY;
        SelectedTileIndex = ExistingIndex;
        bHasValidSelection = true;
        return;
    }

    SelectedTileX = FMath::Max(0, MapSubsystem->GetGridWidth() / 2);
    SelectedTileY = FMath::Max(0, MapSubsystem->GetGridHeight() / 2);

    if (MapSubsystem->TileXYToIndex(SelectedTileX, SelectedTileY, SelectedTileIndex))
    {
        bHasValidSelection = true;
    }
}