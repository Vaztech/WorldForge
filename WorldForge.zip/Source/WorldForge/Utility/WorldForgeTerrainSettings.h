#pragma once

#include "CoreMinimal.h"
#include "Engine/DeveloperSettings.h"
#include "VoxelWorldManager.h"
#include "WorldForgeTerrainSettings.generated.h"

UCLASS(Config = Game, DefaultConfig, meta = (DisplayName = "WorldForge Terrain Settings"))
class WORLDFORGE_API UWorldForgeTerrainSettings : public UDeveloperSettings
{
    GENERATED_BODY()

public:
    UWorldForgeTerrainSettings();

    virtual FName GetCategoryName() const override
    {
        return FName(TEXT("WorldForge"));
    }

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Voxel")
    float ChunkWorldSize = 3200.0f;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Voxel")
    float VoxelSize = 100.0f;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Voxel")
    float TerrainSurfaceZOffset = 50.0f;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Voxel")
    bool bAddGlobalFoundation = true;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Voxel")
    float GlobalFoundationDepthWorld = 5000.0f;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Perlin")
    FPerlinOctaveSettings DefaultPerlinSettings;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Terrain", meta = (ClampMin = "0.0", ClampMax = "1.0"))
    float SandMaxElevationNormalized = 0.35f;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Terrain", meta = (ClampMin = "0.0", ClampMax = "1.0"))
    float RockMinElevationNormalized = 0.75f;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Terrain", meta = (ClampMin = "0.0", ClampMax = "1.0"))
    float SnowMinElevationNormalized = 0.90f;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Water")
    int32 SeaLevelVoxels = 2;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Macro")
    float ContinentFrequency = 0.00018f;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Macro")
    int32 ContinentHeightRangeVoxels = 90;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Macro")
    float ContinentExponent = 2.2f;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Macro")
    float BasinFrequency = 0.00055f;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Macro")
    float BasinThreshold = 0.82f;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Macro")
    int32 LakeBasinDepthVoxels = 14;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Rivers")
    float RiverFrequency = 0.0015f;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Rivers")
    float RiverThreshold = 0.92f;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Rivers")
    int32 RiverCarveDepthVoxels = 5;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Rivers")
    float RiverSharpness = 2.2f;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Terrain|Base", meta = (ClampMin = "0.0"))
    float BaseHeight = 4000.0f;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Terrain|Base", meta = (ClampMin = "0.0"))
    float HeightMultiplier = 6000.0f;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Terrain|Base", meta = (ClampMin = "0.0"))
    float ContinentScale = 0.00005f;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Terrain|Detail", meta = (ClampMin = "0.0"))
    float DetailScale = 0.002f;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Terrain|Detail", meta = (ClampMin = "0.0"))
    float DetailAmplitude = 120.0f;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Terrain|Detail", meta = (ClampMin = "1", ClampMax = "8"))
    int32 DetailOctaves = 3;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Caves")
    bool bEnableCaves = true;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Caves", meta = (ClampMin = "0.0"))
    float CaveFrequency = 0.01f;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Caves", meta = (ClampMin = "0.0", ClampMax = "1.0"))
    float CaveThreshold = 0.45f;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Caves", meta = (ClampMin = "0.0"))
    float CaveSecondOctaveMultiplier = 2.0f;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Caves", meta = (ClampMin = "0.0", ClampMax = "1.0"))
    float CavePrimaryWeight = 0.7f;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Caves", meta = (ClampMin = "0.0", ClampMax = "1.0"))
    float CaveSecondaryWeight = 0.3f;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Performance")
    bool bUseFastTerrainSampling = true;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Debug")
    bool bLogGridConversions = false;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Debug")
    bool bLogTerrainGeneration = true;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Debug")
    bool bLogTerrainRetry = true;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Debug")
    bool bUseFallbackPlacedBlockVisuals = true;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Debug")
    bool bPreferSurfaceAnchoredPlacedBlocks = false;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Debug")
    bool bLogPlacedBlockVisuals = true;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Debug")
    float FallbackPlacedBlockVerticalNudge = 1.0f;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Runtime")
    float TerrainRetryIntervalSeconds = 0.25f;

    UPROPERTY(EditAnywhere, Config, BlueprintReadWrite, Category = "Runtime")
    int32 MaxTerrainRetryCount = 40;
};