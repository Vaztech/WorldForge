#include "Utility/WorldForgeTerrainSettings.h"

UWorldForgeTerrainSettings::UWorldForgeTerrainSettings()
{
    DefaultPerlinSettings.BaseFrequency = 0.005f;
    DefaultPerlinSettings.BaseAmplitude = 3.0f;
    DefaultPerlinSettings.OctaveCount = 4;
    DefaultPerlinSettings.Lacunarity = 2.0f;
    DefaultPerlinSettings.Persistence = 0.5f;
    DefaultPerlinSettings.MinHeight = 4;
    DefaultPerlinSettings.SeedOffset = 0;

    ChunkWorldSize = 3200.0f;
    VoxelSize = 100.0f;
    TerrainSurfaceZOffset = 50.0f;
    bAddGlobalFoundation = true;
    GlobalFoundationDepthWorld = 5000.0f;

    SandMaxElevationNormalized = 0.35f;
    RockMinElevationNormalized = 0.75f;
    SnowMinElevationNormalized = 0.90f;

    SeaLevelVoxels = 2;

    ContinentFrequency = 0.00018f;
    ContinentHeightRangeVoxels = 90;
    ContinentExponent = 2.2f;

    BasinFrequency = 0.00055f;
    BasinThreshold = 0.82f;
    LakeBasinDepthVoxels = 14;

    RiverFrequency = 0.0015f;
    RiverThreshold = 0.92f;
    RiverCarveDepthVoxels = 5;
    RiverSharpness = 2.2f;

    BaseHeight = 4000.0f;
    HeightMultiplier = 6000.0f;
    ContinentScale = 0.00005f;

    DetailScale = 0.002f;
    DetailAmplitude = 120.0f;
    DetailOctaves = 3;

    bEnableCaves = true;
    CaveFrequency = 0.01f;
    CaveThreshold = 0.45f;
    CaveSecondOctaveMultiplier = 2.0f;
    CavePrimaryWeight = 0.7f;
    CaveSecondaryWeight = 0.3f;

    bUseFastTerrainSampling = true;

    bLogGridConversions = false;
    bLogTerrainGeneration = true;
    bLogTerrainRetry = true;
    bUseFallbackPlacedBlockVisuals = true;
    bPreferSurfaceAnchoredPlacedBlocks = false;
    bLogPlacedBlockVisuals = true;
    FallbackPlacedBlockVerticalNudge = 1.0f;

    TerrainRetryIntervalSeconds = 0.25f;
    MaxTerrainRetryCount = 40;
}