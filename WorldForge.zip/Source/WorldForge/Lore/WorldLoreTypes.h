// WorldLoreTypes.h — WorldForge Lore Infrastructure
// All lore data structs. FWorldLoreState is IMMUTABLE after generation.
// Every field tagged SaveGame per project invariant.
//
// CROSS-REFERENCE CONVENTION:
//   Lore-internal IDs (ArtifactID, CityID, LegendID, ColonistID) → FName
//   Cross-refs to FCivilizationData/FHistoricalFigure             → int32
//   (matches WorldForgeDataTypes.h where CivID/FigureID are int32)

#pragma once

#include "CoreMinimal.h"
#include "GameplayTagContainer.h"
#include "WorldLoreTypes.generated.h"

// ─────────────────────────────────────────────
//  Artifacts — legendary items forged by civilizations
// ─────────────────────────────────────────────

USTRUCT(BlueprintType)
struct WORLDFORGE_API FLoreArtifact
{
	GENERATED_BODY()

	UPROPERTY(SaveGame, BlueprintReadOnly)
	FName ArtifactID;

	UPROPERTY(SaveGame, BlueprintReadOnly)
	FText DisplayName;

	UPROPERTY(SaveGame, BlueprintReadOnly)
	FText Description;

	/** e.g. WorldForge.Artifact.Type.Weapon, .Armor, .Relic, .Tome */
	UPROPERTY(SaveGame, BlueprintReadOnly)
	FGameplayTag ArtifactType;

	UPROPERTY(SaveGame, BlueprintReadOnly)
	int32 ForgedByCivID = -1;                   // ← was FName

	UPROPERTY(SaveGame, BlueprintReadOnly)
	int32 ForgedByFigureID = -1;                // ← was FName

	UPROPERTY(SaveGame, BlueprintReadOnly)
	int32 ForgedInEpoch = -1;

	/** -1 if lost to ruins or destroyed */
	UPROPERTY(SaveGame, BlueprintReadOnly)
	int32 CurrentHolderCivID = -1;              // ← was FName

	/** If lost, which fallen city holds it (lore-internal FName) */
	UPROPERTY(SaveGame, BlueprintReadOnly)
	FName LostInCityID;

	/** e.g. Cursed, Holy, Sentient, Destructive, Protective */
	UPROPERTY(SaveGame, BlueprintReadOnly)
	FGameplayTagContainer TraitTags;

	/** Power rating 0.0–1.0 for gameplay integration */
	UPROPERTY(SaveGame, BlueprintReadOnly)
	float PowerRating = 0.0f;
};

// ─────────────────────────────────────────────
//  Fallen Cities — ruins with history
// ─────────────────────────────────────────────

UENUM(BlueprintType)
enum class ECityFallCause : uint8
{
	War,
	Plague,
	Famine,
	NaturalDisaster,
	CosmicWrath,
	CivilWar,
	Abandonment
};

USTRUCT(BlueprintType)
struct WORLDFORGE_API FLoreFallenCity
{
	GENERATED_BODY()

	UPROPERTY(SaveGame, BlueprintReadOnly)
	FName CityID;

	UPROPERTY(SaveGame, BlueprintReadOnly)
	FText DisplayName;

	UPROPERTY(SaveGame, BlueprintReadOnly)
	FIntPoint TileCoord = FIntPoint::ZeroValue;

	UPROPERTY(SaveGame, BlueprintReadOnly)
	int32 OriginalCivID = -1;                   // ← was FName

	/** Which civ destroyed it, if War. -1 = no conqueror */
	UPROPERTY(SaveGame, BlueprintReadOnly)
	int32 ConquerorCivID = -1;                  // ← was FName

	UPROPERTY(SaveGame, BlueprintReadOnly)
	int32 FoundedInEpoch = -1;

	UPROPERTY(SaveGame, BlueprintReadOnly)
	int32 FellInEpoch = -1;

	UPROPERTY(SaveGame, BlueprintReadOnly)
	ECityFallCause CauseOfFall = ECityFallCause::Abandonment;

	UPROPERTY(SaveGame, BlueprintReadOnly)
	FText LoreSnippet;

	/** Artifacts buried in these ruins (lore-internal FName IDs) */
	UPROPERTY(SaveGame, BlueprintReadOnly)
	TArray<FName> ArtifactsLostHere;

	/** Biome at the ruin site, for decoration pass integration */
	UPROPERTY(SaveGame, BlueprintReadOnly)
	FGameplayTag BiomeTag;

	/** Danger level 0.0–1.0 (higher = more guardians/traps in gameplay) */
	UPROPERTY(SaveGame, BlueprintReadOnly)
	float DangerRating = 0.0f;
};

// ─────────────────────────────────────────────
//  Legends — synthesized narratives
// ─────────────────────────────────────────────

UENUM(BlueprintType)
enum class EWorldForgeLoreLegendType : uint8
{
	HeroicBattle,
	TragicFall,
	Creation,
	Discovery,
	Betrayal,
	Prophecy,
	Migration
};

USTRUCT(BlueprintType)
struct WORLDFORGE_API FLoreLegend
{
	GENERATED_BODY()

	UPROPERTY(SaveGame, BlueprintReadOnly)
	FName LegendID;

	UPROPERTY(SaveGame, BlueprintReadOnly)
	FText Title;

	UPROPERTY(SaveGame, BlueprintReadOnly)
	FText NarrativeText;

	UPROPERTY(SaveGame, BlueprintReadOnly)
	EWorldForgeLoreLegendType LegendType = EWorldForgeLoreLegendType::HeroicBattle;

	/** Which cosmic domain this legend relates to (War, Knowledge, etc.) */
	UPROPERTY(SaveGame, BlueprintReadOnly)
	FGameplayTag CosmicDomain;

	UPROPERTY(SaveGame, BlueprintReadOnly)
	TArray<int32> ReferencedCivIDs;             // ← was TArray<FName>

	UPROPERTY(SaveGame, BlueprintReadOnly)
	TArray<FName> ReferencedArtifactIDs;        // stays FName (lore-internal)

	UPROPERTY(SaveGame, BlueprintReadOnly)
	TArray<int32> ReferencedFigureIDs;          // ← was TArray<FName>

	UPROPERTY(SaveGame, BlueprintReadOnly)
	TArray<FName> ReferencedCityIDs;            // stays FName (lore-internal)

	UPROPERTY(SaveGame, BlueprintReadOnly)
	int32 Epoch = -1;

	/** How widely known: 0.0 = local myth, 1.0 = known across all civs */
	UPROPERTY(SaveGame, BlueprintReadOnly)
	float Renown = 0.0f;
};

// ─────────────────────────────────────────────
//  Colonist Backstories — starting colonist lore
// ─────────────────────────────────────────────

UENUM(BlueprintType)
enum class EBackstoryArchetype : uint8
{
	Exile,
	Veteran,
	Scholar,
	Orphan,
	Merchant,
	Criminal,
	Pilgrim,
	Artisan
};

USTRUCT(BlueprintType)
struct WORLDFORGE_API FColonistBackstory
{
	GENERATED_BODY()

	UPROPERTY(SaveGame, BlueprintReadOnly)
	FName ColonistID;

	UPROPERTY(SaveGame, BlueprintReadOnly)
	FText DisplayName;

	UPROPERTY(SaveGame, BlueprintReadOnly)
	int32 HomeCivID = -1;                       // ← was FName

	UPROPERTY(SaveGame, BlueprintReadOnly)
	EBackstoryArchetype Archetype = EBackstoryArchetype::Exile;

	UPROPERTY(SaveGame, BlueprintReadOnly)
	FText BackstoryText;

	/** e.g. WorldForge.Personality.Brave, .Curious, .Paranoid */
	UPROPERTY(SaveGame, BlueprintReadOnly)
	FGameplayTagContainer PersonalityTraits;

	/** Artifacts this colonist knows about (quest hooks — lore FName IDs) */
	UPROPERTY(SaveGame, BlueprintReadOnly)
	TArray<FName> KnownArtifactIDs;

	/** Legends this colonist can retell (lore FName IDs) */
	UPROPERTY(SaveGame, BlueprintReadOnly)
	TArray<FName> KnownLegendIDs;

	/** Skill biases derived from archetype, 0.0–1.0 */
	UPROPERTY(SaveGame, BlueprintReadOnly)
	float CombatAptitude = 0.0f;

	UPROPERTY(SaveGame, BlueprintReadOnly)
	float CraftingAptitude = 0.0f;

	UPROPERTY(SaveGame, BlueprintReadOnly)
	float SocialAptitude = 0.0f;

	UPROPERTY(SaveGame, BlueprintReadOnly)
	float ScholarAptitude = 0.0f;
};

// ─────────────────────────────────────────────
//  FWorldLoreState — the top-level container
//  IMMUTABLE after world generation completes.
// ─────────────────────────────────────────────

USTRUCT(BlueprintType)
struct WORLDFORGE_API FWorldLoreState
{
	GENERATED_BODY()

	UPROPERTY(SaveGame, BlueprintReadOnly)
	TArray<FLoreArtifact> Artifacts;

	UPROPERTY(SaveGame, BlueprintReadOnly)
	TArray<FLoreFallenCity> FallenCities;

	UPROPERTY(SaveGame, BlueprintReadOnly)
	TArray<FLoreLegend> Legends;

	UPROPERTY(SaveGame, BlueprintReadOnly)
	TArray<FColonistBackstory> ColonistBackstories;

	/** Generation seed — for deterministic replay */
	UPROPERTY(SaveGame, BlueprintReadOnly)
	int32 LoreSeed = 0;

	// ── Read-only lookups (const-only API enforces immutability) ──

	const FLoreArtifact* FindArtifact(FName ID) const;
	const FLoreFallenCity* FindFallenCity(FName ID) const;
	const FLoreLegend* FindLegend(FName ID) const;
	const FColonistBackstory* FindColonist(FName ID) const;

	TArray<const FLoreArtifact*>   GetArtifactsByCiv(int32 CivID) const;    // ← was FName
	TArray<const FLoreFallenCity*> GetFallenCitiesByCiv(int32 CivID) const; // ← was FName
	TArray<const FLoreLegend*>     GetLegendsByEpoch(int32 Epoch) const;

	int32 NumArtifacts()   const { return Artifacts.Num(); }
	int32 NumFallenCities() const { return FallenCities.Num(); }
	int32 NumLegends()     const { return Legends.Num(); }
	int32 NumColonists()   const { return ColonistBackstories.Num(); }

	/** Debug summary for PIE log */
	FString GetSummaryString() const;
};