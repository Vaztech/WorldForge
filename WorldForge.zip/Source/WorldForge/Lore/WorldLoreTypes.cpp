// WorldLoreTypes.cpp — Lookup implementations for FWorldLoreState

#include "WorldLoreTypes.h"

// ─────────────────────────────────────────────
//  Single-item lookups
// ─────────────────────────────────────────────

const FLoreArtifact* FWorldLoreState::FindArtifact(FName ID) const
{
	return Artifacts.FindByPredicate([ID](const FLoreArtifact& A) { return A.ArtifactID == ID; });
}

const FLoreFallenCity* FWorldLoreState::FindFallenCity(FName ID) const
{
	return FallenCities.FindByPredicate([ID](const FLoreFallenCity& C) { return C.CityID == ID; });
}

const FLoreLegend* FWorldLoreState::FindLegend(FName ID) const
{
	return Legends.FindByPredicate([ID](const FLoreLegend& L) { return L.LegendID == ID; });
}

const FColonistBackstory* FWorldLoreState::FindColonist(FName ID) const
{
	return ColonistBackstories.FindByPredicate([ID](const FColonistBackstory& C) { return C.ColonistID == ID; });
}

// ─────────────────────────────────────────────
//  Filtered queries
// ─────────────────────────────────────────────

TArray<const FLoreArtifact*> FWorldLoreState::GetArtifactsByCiv(int32 CivID) const
{
	TArray<const FLoreArtifact*> Result;
	for (const FLoreArtifact& A : Artifacts)
	{
		if (A.ForgedByCivID == CivID)
		{
			Result.Add(&A);
		}
	}
	return Result;
}

TArray<const FLoreFallenCity*> FWorldLoreState::GetFallenCitiesByCiv(int32 CivID) const
{
	TArray<const FLoreFallenCity*> Result;
	for (const FLoreFallenCity& C : FallenCities)
	{
		if (C.OriginalCivID == CivID)
		{
			Result.Add(&C);
		}
	}
	return Result;
}

TArray<const FLoreLegend*> FWorldLoreState::GetLegendsByEpoch(int32 Epoch) const
{
	TArray<const FLoreLegend*> Result;
	for (const FLoreLegend& L : Legends)
	{
		if (L.Epoch == Epoch)
		{
			Result.Add(&L);
		}
	}
	return Result;
}

// ─────────────────────────────────────────────
//  Debug
// ─────────────────────────────────────────────

FString FWorldLoreState::GetSummaryString() const
{
	return FString::Printf(
		TEXT("WorldLoreState | Seed:%d | Artifacts:%d | FallenCities:%d | Legends:%d | Colonists:%d"),
		LoreSeed,
		Artifacts.Num(),
		FallenCities.Num(),
		Legends.Num(),
		ColonistBackstories.Num()
	);
}