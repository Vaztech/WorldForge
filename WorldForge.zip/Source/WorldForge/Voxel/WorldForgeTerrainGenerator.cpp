#include "WorldForgeTerrainGenerator.h"

#include "VoxelMaterialBuilder.h"
#include "Utility/WorldForgeTerrainSettings.h"

// Layer ids are defined in WorldForgeTerrainGenerator.h.
// Keep a single source of truth there.


namespace
{
    static float WF_Bilerp(float V00, float V10, float V01, float V11, float FX, float FY)
    {
        const float X0 = FMath::Lerp(V00, V10, FX);
        const float X1 = FMath::Lerp(V01, V11, FX);
        return FMath::Lerp(X0, X1, FY);
    }

    static float WF_FractalPerlin2D(float X, float Y, float Frequency, int32 Octaves)
    {
        float Total = 0.0f;
        float Amplitude = 1.0f;
        float SumAmplitude = 0.0f;
        float CurrentFrequency = FMath::Max(KINDA_SMALL_NUMBER, Frequency);

        for (int32 OctaveIndex = 0; OctaveIndex < FMath::Max(1, Octaves); ++OctaveIndex)
        {
            const float Sample = FMath::PerlinNoise2D(FVector2D(X * CurrentFrequency, Y * CurrentFrequency));
            Total += Sample * Amplitude;
            SumAmplitude += Amplitude;

            CurrentFrequency *= 2.0f;
            Amplitude *= 0.5f;
        }

        if (SumAmplitude <= KINDA_SMALL_NUMBER)
        {
            return 0.0f;
        }

        return Total / SumAmplitude;
    }

    static float WF_Perlin3D(float X, float Y, float Z)
    {
        return FMath::PerlinNoise3D(FVector(X, Y, Z));
    }
}

TVoxelSharedRef<FVoxelGeneratorInstance> UWorldForgeTerrainGenerator::GetInstance()
{
    return MakeVoxelShared<FWorldForgeTerrainGeneratorInstance>(*this);
}

FWorldForgeTerrainGeneratorInstance::FWorldForgeTerrainGeneratorInstance(UWorldForgeTerrainGenerator& GeneratorObject)
    : Super(&GeneratorObject)
    , TerrainSnapshot(GeneratorObject.TerrainSnapshot)
    , Seed(GeneratorObject.Seed)
{
}

void FWorldForgeTerrainGeneratorInstance::Init(const FVoxelGeneratorInit& InitStruct)
{
    Noise2D.SetSeed(Seed);
    CaveNoise.SetSeed(Seed + 1337);
}

v_flt FWorldForgeTerrainGeneratorInstance::GetValueImpl(
    v_flt X,
    v_flt Y,
    v_flt Z,
    int32 LOD,
    const FVoxelItemStack& Items) const
{
    if (!IsSnapshotValid())
    {
        return 1.0f;
    }

    const float SurfaceHeight = ComputeSurfaceHeight(X, Y);

    float Density = Z - SurfaceHeight;

    if (const FVoxelBiomeProfile* Profile = SamplePrimaryBiomeProfile(X, Y))
    {
        Density += ComputeCaveDensity(X, Y, Z, *Profile);
    }

    if (TerrainSnapshot.bAddGlobalFoundation)
    {
        const float FoundationDepth = static_cast<float>(TerrainSnapshot.GetFoundationDepthVoxels());

        const float DistanceToFoundationTop = Z;
        const float DistanceToFoundationBottom = -(Z + FoundationDepth);
        const float FoundationDensity = FMath::Max(DistanceToFoundationTop, DistanceToFoundationBottom);

        Density = FMath::Min(Density, FoundationDensity);
    }

    return Density;
}

FVoxelMaterial FWorldForgeTerrainGeneratorInstance::GetMaterialImpl(
    v_flt X,
    v_flt Y,
    v_flt Z,
    int32 LOD,
    const FVoxelItemStack& Items) const
{
    if (!IsSnapshotValid())
    {
        return FVoxelMaterial::Default();
    }

    const float SurfaceHeight = ComputeSurfaceHeight(X, Y);
    const float DepthBelowSurface = SurfaceHeight - Z;

    const int32 SurfaceLayer = ClassifyTerrainMaterialLayer(X, Y, SurfaceHeight);

    // Surface voxel gets the classified layer directly.
    if (DepthBelowSurface <= 1.5f)
    {
        return MakeVoxelMaterialFromLayer(SurfaceLayer);
    }

    // Shallow subsurface keeps some logical continuity.
    if (DepthBelowSurface <= 4.5f)
    {
        switch (SurfaceLayer)
        {
        case TerrainLayer_Water:
            return MakeVoxelMaterialFromLayer(TerrainLayer_Water);

        case TerrainLayer_Sand:
            return MakeVoxelMaterialFromLayer(TerrainLayer_Sand);

        case TerrainLayer_Snow:
            return MakeVoxelMaterialFromLayer(TerrainLayer_Dirt);

        case TerrainLayer_Rock:
            return MakeVoxelMaterialFromLayer(TerrainLayer_Rock);

        case TerrainLayer_Grass:
        case TerrainLayer_Dirt:
        default:
            return MakeVoxelMaterialFromLayer(TerrainLayer_Dirt);
        }
    }

    // Deep underground remains rock.
    // Water is only a surface/shallow classification here.
    return MakeVoxelMaterialFromLayer(TerrainLayer_Rock);
}

TVoxelRange<v_flt> FWorldForgeTerrainGeneratorInstance::GetValueRangeImpl(
    const FVoxelIntBox& Bounds,
    int32 LOD,
    const FVoxelItemStack& Items) const
{
    if (!IsSnapshotValid())
    {
        return TVoxelRange<v_flt>(1.0f, 1.0f);
    }

    const float Surface00 = ComputeSurfaceHeight(Bounds.Min.X, Bounds.Min.Y);
    const float Surface01 = ComputeSurfaceHeight(Bounds.Min.X, Bounds.Max.Y);
    const float Surface10 = ComputeSurfaceHeight(Bounds.Max.X, Bounds.Min.Y);
    const float Surface11 = ComputeSurfaceHeight(Bounds.Max.X, Bounds.Max.Y);

    const float MinSurface = FMath::Min(FMath::Min(Surface00, Surface01), FMath::Min(Surface10, Surface11));
    const float MaxSurface = FMath::Max(FMath::Max(Surface00, Surface01), FMath::Max(Surface10, Surface11));

    const float MinValue = static_cast<float>(Bounds.Min.Z) - MaxSurface;
    const float MaxValue = static_cast<float>(Bounds.Max.Z) - MinSurface;

    if (TerrainSnapshot.bAddGlobalFoundation)
    {
        const float FoundationDepth = static_cast<float>(TerrainSnapshot.GetFoundationDepthVoxels());

        const float FoundationAtMinZ = FMath::Max(
            static_cast<float>(Bounds.Min.Z),
            -(static_cast<float>(Bounds.Min.Z) + FoundationDepth)
        );

        const float FoundationAtMaxZ = FMath::Max(
            static_cast<float>(Bounds.Max.Z),
            -(static_cast<float>(Bounds.Max.Z) + FoundationDepth)
        );

        const float FoundationMin = FMath::Min(FoundationAtMinZ, FoundationAtMaxZ);

        return TVoxelRange<v_flt>(FMath::Min(MinValue, FoundationMin), MaxValue);
    }

    return TVoxelRange<v_flt>(MinValue, MaxValue);
}

FVector FWorldForgeTerrainGeneratorInstance::GetUpVector(v_flt X, v_flt Y, v_flt Z) const
{
    return FVector::UpVector;
}

// ---------------------------------------------------------------------------
// BUG 2 FIX: SampleContinentHeight is intentionally kept compiled but is no
// longer called from ComputeMacroBaseHeight. It used its own independent Perlin
// noise (fixed offsets, generator Seed) that bore no mathematical relationship
// to the pipeline's Step02/Step03 elevation noise (which uses RNG-derived
// TerrainOffsetX/Y). Calling both produced continent shapes that contradicted
// the tile map. The macro shape is now driven entirely by tile elevation data
// sampled via SampleTileElevationBilinear, which is the source of truth for the
// world map as well.
// ---------------------------------------------------------------------------
float FWorldForgeTerrainGeneratorInstance::SampleContinentHeight(float X, float Y) const
{
    const float SuperLowFreq = TerrainSnapshot.ContinentFrequency * 0.18f;
    const float LowFreq = TerrainSnapshot.ContinentFrequency * 0.55f;
    const float MidFreq = TerrainSnapshot.ContinentFrequency * 1.35f;

    const float MacroNoise = FMath::PerlinNoise2D(FVector2D(
        (X + 1403.0f) * SuperLowFreq,
        (Y + 917.0f) * SuperLowFreq
    ));

    const float ShapeNoise = FMath::PerlinNoise2D(FVector2D(
        (X + 4131.0f) * LowFreq,
        (Y + 1729.0f) * LowFreq
    ));

    const float InteriorNoise = FMath::PerlinNoise2D(FVector2D(
        (X + 811.0f) * MidFreq,
        (Y + 2677.0f) * MidFreq
    ));

    const float Macro01 = FMath::Clamp((MacroNoise + 1.0f) * 0.5f, 0.0f, 1.0f);
    const float Shape01 = FMath::Clamp((ShapeNoise + 1.0f) * 0.5f, 0.0f, 1.0f);
    const float Interior01 = FMath::Clamp((InteriorNoise + 1.0f) * 0.5f, 0.0f, 1.0f);

    // Strong continent mask: large ocean / large landmass separation
    const float ContinentMask = FMath::Pow(Macro01, 1.85f);

    // Blend in some secondary shape without breaking the large landmass
    const float ContinentalShape = FMath::Lerp(ContinentMask, Shape01, 0.28f);

    // Interior variation should mostly affect land, not create new islands
    const float LandSignal =
        (ContinentalShape * 0.82f) +
        (Interior01 * 0.18f);

    // Shift downward so oceans dominate unless the mask clearly says "land"
    const float SignedHeight = (LandSignal - 0.44f) * 2.0f;

    return SignedHeight * static_cast<float>(TerrainSnapshot.ContinentHeightRangeVoxels);
}

float FWorldForgeTerrainGeneratorInstance::SampleBasinDepth(float X, float Y) const
{
    const float BasinNoise = FMath::PerlinNoise2D(FVector2D(
        (X + 913.0f) * (TerrainSnapshot.BasinFrequency * 0.65f),
        (Y + 271.0f) * (TerrainSnapshot.BasinFrequency * 0.65f)
    ));

    const float Basin01 = FMath::Clamp((BasinNoise + 1.0f) * 0.5f, 0.0f, 1.0f);

    // Make basins rarer
    const float BasinThreshold = FMath::Clamp(TerrainSnapshot.BasinThreshold + 0.10f, 0.0f, 0.95f);
    if (Basin01 < BasinThreshold)
    {
        return 0.0f;
    }

    const float BasinAlpha =
        (Basin01 - BasinThreshold) /
        FMath::Max(0.001f, 1.0f - BasinThreshold);

    const float ShapedAlpha = FMath::Pow(FMath::Clamp(BasinAlpha, 0.0f, 1.0f), 1.8f);

    return ShapedAlpha * static_cast<float>(TerrainSnapshot.LakeBasinDepthVoxels) * 0.55f;
}

float FWorldForgeTerrainGeneratorInstance::SampleRiverCarve(float X, float Y) const
{
    const float RiverNoise = FMath::PerlinNoise2D(FVector2D(
        (X + 1703.0f) * TerrainSnapshot.RiverFrequency,
        (Y + 811.0f) * TerrainSnapshot.RiverFrequency
    ));

    const float RiverMask = 1.0f - FMath::Abs(RiverNoise);

    if (RiverMask < TerrainSnapshot.RiverThreshold)
    {
        return 0.0f;
    }

    const float RiverAlpha =
        (RiverMask - TerrainSnapshot.RiverThreshold) /
        FMath::Max(0.001f, 1.0f - TerrainSnapshot.RiverThreshold);

    const float ShapedRiver = FMath::Pow(
        FMath::Clamp(RiverAlpha, 0.0f, 1.0f),
        FMath::Max(0.1f, TerrainSnapshot.RiverSharpness)
    );

    // Moderate carve only.
    return ShapedRiver * static_cast<float>(TerrainSnapshot.RiverCarveDepthVoxels) * 1.15f;
}

// ---------------------------------------------------------------------------
// BUG 1 FIX: The Voxel Plugin calls GetValueImpl with signed, origin-centered
// voxel coordinates � world center is (0,0), not (0,0) in tile space. The tile
// grid is 0-indexed (0..GridWidth-1). Without the half-grid offset below, voxel
// X=0 maps to tile column 0 (the corner) instead of tile column GridWidth/2
// (the center), and every negative-X voxel clamps to tile 0. The entire left
// and bottom halves of the world read the same single clamped tile, so all
// pipeline elevation and biome data is ignored for most of the terrain.
// ---------------------------------------------------------------------------
float FWorldForgeTerrainGeneratorInstance::SampleTileElevationBilinear(float VoxelX, float VoxelY) const
{
    if (!IsSnapshotValid())
    {
        return 0.0f;
    }

    const float ChunkSize = static_cast<float>(FMath::Max(1, TerrainSnapshot.ChunkSizeVoxels));

    // BUG 1 FIX: shift signed voxel coordinates to 0-indexed tile space by
    // adding half the grid extent (in tile units) before dividing by ChunkSize.
    const float HalfGridX = static_cast<float>(TerrainSnapshot.GridWidth) * 0.5f;
    const float HalfGridY = static_cast<float>(TerrainSnapshot.GridHeight) * 0.5f;

    const float CellX = (VoxelX / ChunkSize) + HalfGridX;
    const float CellY = (VoxelY / ChunkSize) + HalfGridY;

    const int32 X0 = FMath::FloorToInt(CellX);
    const int32 Y0 = FMath::FloorToInt(CellY);
    const int32 X1 = X0 + 1;
    const int32 Y1 = Y0 + 1;

    const float FX = CellX - static_cast<float>(X0);
    const float FY = CellY - static_cast<float>(Y0);

    const FIntPoint C00 = TerrainSnapshot.ClampCell(FIntPoint(X0, Y0));
    const FIntPoint C10 = TerrainSnapshot.ClampCell(FIntPoint(X1, Y0));
    const FIntPoint C01 = TerrainSnapshot.ClampCell(FIntPoint(X0, Y1));
    const FIntPoint C11 = TerrainSnapshot.ClampCell(FIntPoint(X1, Y1));

    const float E00 = TerrainSnapshot.GetTileElevation(C00, 0.0f);
    const float E10 = TerrainSnapshot.GetTileElevation(C10, 0.0f);
    const float E01 = TerrainSnapshot.GetTileElevation(C01, 0.0f);
    const float E11 = TerrainSnapshot.GetTileElevation(C11, 0.0f);

    return WF_Bilerp(E00, E10, E01, E11, FX, FY);
}

// ---------------------------------------------------------------------------
// BUG 1 FIX (same offset as SampleTileElevationBilinear): voxel coords are
// signed/centered; tile grid is 0-indexed. Without the half-grid shift, the
// biome profile lookup is wrong for the entire left/bottom half of the world.
// ---------------------------------------------------------------------------
const FVoxelBiomeProfile* FWorldForgeTerrainGeneratorInstance::SamplePrimaryBiomeProfile(float VoxelX, float VoxelY) const
{
    if (!IsSnapshotValid())
    {
        return nullptr;
    }

    const float ChunkSizeF = static_cast<float>(FMath::Max(1, TerrainSnapshot.ChunkSizeVoxels));

    // BUG 1 FIX: same signed->0-indexed conversion as SampleTileElevationBilinear.
    const float HalfGridX = static_cast<float>(TerrainSnapshot.GridWidth) * 0.5f;
    const float HalfGridY = static_cast<float>(TerrainSnapshot.GridHeight) * 0.5f;

    const int32 ChunkX = FMath::FloorToInt((VoxelX / ChunkSizeF) + HalfGridX);
    const int32 ChunkY = FMath::FloorToInt((VoxelY / ChunkSizeF) + HalfGridY);

    const FIntPoint ChunkCell = TerrainSnapshot.ClampCell(FIntPoint(ChunkX, ChunkY));
    return TerrainSnapshot.GetVoxelProfile(ChunkCell);
}

// ---------------------------------------------------------------------------
// BUG 2 FIX: SampleContinentHeight is no longer called. The macro shape is
// driven entirely by tile elevation from the pipeline, which is also what the
// world map renders. Using a second, independent Perlin-based continent signal
// here produced terrain that contradicted the map.
//
// The tile elevation field already encodes continent shape, mountain ranges, and
// ocean basins from Step02 + Step03. Scaling it through a power curve and
// mapping it to the full ContinentHeightRangeVoxels range gives mountains their
// proper height and keeps low-elevation tiles at or below sea level.
// ---------------------------------------------------------------------------
float FWorldForgeTerrainGeneratorInstance::ComputeMacroBaseHeight(float VoxelX, float VoxelY) const
{
    const float TileElevation = FMath::Clamp(SampleTileElevationBilinear(VoxelX, VoxelY), 0.0f, 1.0f);
    const float BlendedBasin = SampleBasinDepth(VoxelX, VoxelY);

    // Convert 0..1 tile elevation into signed continent relief around sea level.
    // 0.5 = near sea level, below that trends ocean, above that trends land.
    const float Signed01 = (TileElevation - 0.5f) * 2.0f; // [-1, +1]

    // Shape it without losing the sign.
    const float SignedShaped =
        FMath::Sign(Signed01) *
        FMath::Pow(FMath::Abs(Signed01), FMath::Max(0.1f, TerrainSnapshot.ContinentExponent));

    const float ContinentHeight =
        SignedShaped * static_cast<float>(TerrainSnapshot.ContinentHeightRangeVoxels);

    return
        static_cast<float>(TerrainSnapshot.SeaLevelVoxels) +
        ContinentHeight -
        BlendedBasin;
}

float FWorldForgeTerrainGeneratorInstance::ComputeDetailHeight(float VoxelX, float VoxelY, const FVoxelBiomeProfile& Profile) const
{
    const float SafeVoxelSize = FMath::Max(KINDA_SMALL_NUMBER, TerrainSnapshot.VoxelSize);

    const UWorldForgeTerrainSettings* Settings = GetDefault<UWorldForgeTerrainSettings>();

    const float RawAmplitudeVoxels = Profile.NoiseAmplitude / SafeVoxelSize;
    const float DetailAmplitudeVoxels = FMath::Clamp(
        RawAmplitudeVoxels * Settings->DetailAmplitude * 0.01f,
        0.0f,
        64.0f
    );

    const float DetailFrequency = FMath::Max(0.0001f, Settings->DetailScale);

    const float NoiseValue = WF_FractalPerlin2D(
        VoxelX + static_cast<float>(Seed),
        VoxelY + static_cast<float>(Seed * 2),
        DetailFrequency,
        Settings->DetailOctaves
    );

    return NoiseValue * DetailAmplitudeVoxels;
}

float FWorldForgeTerrainGeneratorInstance::ComputeSurfaceHeight(float VoxelX, float VoxelY) const
{
    const FVoxelBiomeProfile* Profile = SamplePrimaryBiomeProfile(VoxelX, VoxelY);

    const float MacroBaseHeight = ComputeMacroBaseHeight(VoxelX, VoxelY);
    const float RiverCarve = SampleRiverCarve(VoxelX, VoxelY);

    float DetailHeight = 0.0f;
    if (Profile)
    {
        DetailHeight = ComputeDetailHeight(VoxelX, VoxelY, *Profile);
    }

    DetailHeight = FMath::Clamp(DetailHeight, -32.0f, 32.0f);

    // Broad valley field only.
    const float ValleyNoise = WF_FractalPerlin2D(
        VoxelX + 7001.0f,
        VoxelY + 991.0f,
        FMath::Max(0.00005f, TerrainSnapshot.ContinentFrequency * 1.4f),
        2
    );

    const float Valley01 = FMath::Clamp((ValleyNoise + 1.0f) * 0.5f, 0.0f, 1.0f);
    const float ValleyMask = FMath::Pow(1.0f - Valley01, 1.8f);

    const float RelativeLandHeight =
        FMath::Max(0.0f, MacroBaseHeight - static_cast<float>(TerrainSnapshot.SeaLevelVoxels));

    const float HighlandMask = FMath::Clamp(
        RelativeLandHeight /
        FMath::Max(1.0f, static_cast<float>(TerrainSnapshot.ContinentHeightRangeVoxels) * 0.55f),
        0.0f,
        1.0f
    );

    const float ValleyCarve = ValleyMask * HighlandMask * 3.0f;

    float SurfaceHeight = MacroBaseHeight + DetailHeight - ValleyCarve - RiverCarve;

    SurfaceHeight = FMath::Max(
        static_cast<float>(TerrainSnapshot.SeaLevelVoxels - TerrainSnapshot.LakeBasinDepthVoxels),
        SurfaceHeight
    );

    return SurfaceHeight;
}

float FWorldForgeTerrainGeneratorInstance::ComputeCaveDensity(float X, float Y, float Z, const FVoxelBiomeProfile& Profile) const
{
    if (!IsSnapshotValid())
    {
        return 0.0f;
    }

    const UWorldForgeTerrainSettings* Settings = GetDefault<UWorldForgeTerrainSettings>();

    if (!Settings->bEnableCaves)
    {
        return 0.0f;
    }

    const float SurfaceHeight = ComputeSurfaceHeight(X, Y);
    const float DepthBelowSurface = SurfaceHeight - Z;

    if (DepthBelowSurface < 12.0f || DepthBelowSurface > 96.0f)
    {
        return 0.0f;
    }

    const float CaveFreq = Settings->CaveFrequency;

    const float N1 = WF_Perlin3D(
        (X + static_cast<float>(Seed) * 1.17f) * CaveFreq,
        (Y + static_cast<float>(Seed) * 1.73f) * CaveFreq,
        (Z + static_cast<float>(Seed) * 2.11f) * CaveFreq
    );

    const float N2 = WF_Perlin3D(
        (X + 913.0f + static_cast<float>(Seed) * 0.37f) * (CaveFreq * Settings->CaveSecondOctaveMultiplier),
        (Y + 271.0f + static_cast<float>(Seed) * 0.53f) * (CaveFreq * Settings->CaveSecondOctaveMultiplier),
        (Z + 611.0f + static_cast<float>(Seed) * 0.89f) * (CaveFreq * Settings->CaveSecondOctaveMultiplier)
    );

    const float CaveNoiseValue =
        (N1 * Settings->CavePrimaryWeight) +
        (N2 * Settings->CaveSecondaryWeight);

    const float DepthAlpha = FMath::Clamp((DepthBelowSurface - 12.0f) / 48.0f, 0.0f, 1.0f);

    return (CaveNoiseValue - Settings->CaveThreshold) * DepthAlpha * 18.0f;
}

float FWorldForgeTerrainGeneratorInstance::ComputeApproximateSlopeDegrees(float VoxelX, float VoxelY) const
{
    const float SampleOffset = static_cast<float>(FMath::Max(1, TerrainSnapshot.ChunkSizeVoxels));

    const float Hx0 = ComputeSurfaceHeight(VoxelX - SampleOffset, VoxelY);
    const float Hx1 = ComputeSurfaceHeight(VoxelX + SampleOffset, VoxelY);
    const float Hy0 = ComputeSurfaceHeight(VoxelX, VoxelY - SampleOffset);
    const float Hy1 = ComputeSurfaceHeight(VoxelX, VoxelY + SampleOffset);

    const float Dx = (Hx1 - Hx0) / (2.0f * SampleOffset);
    const float Dy = (Hy1 - Hy0) / (2.0f * SampleOffset);
    const float GradientMagnitude = FMath::Sqrt((Dx * Dx) + (Dy * Dy));

    return FMath::RadiansToDegrees(FMath::Atan(GradientMagnitude));
}

float FWorldForgeTerrainGeneratorInstance::ComputeNormalizedSurfaceElevation(float SurfaceHeight) const
{
    const float MinElevation =
        static_cast<float>(TerrainSnapshot.SeaLevelVoxels - TerrainSnapshot.LakeBasinDepthVoxels);

    const float MaxElevation =
        static_cast<float>(TerrainSnapshot.SeaLevelVoxels) +
        static_cast<float>(TerrainSnapshot.ContinentHeightRangeVoxels) +
        20.0f +
        4.0f;

    if (MaxElevation <= MinElevation)
    {
        return 0.0f;
    }

    return FMath::Clamp((SurfaceHeight - MinElevation) / (MaxElevation - MinElevation), 0.0f, 1.0f);
}

int32 FWorldForgeTerrainGeneratorInstance::ClassifyTerrainMaterialLayer(float VoxelX, float VoxelY, float SurfaceHeight) const
{
    const float NormalizedElevation = ComputeNormalizedSurfaceElevation(SurfaceHeight);
    const float SlopeDegrees = ComputeApproximateSlopeDegrees(VoxelX, VoxelY);

    constexpr float SnowMinElevationNormalizedLocal = 0.84f;
    constexpr float UpperRockElevationNormalizedLocal = 0.62f;
    constexpr float HighlandDirtElevationNormalizedLocal = 0.55f;

    constexpr float CoastBandVoxels = 2.0f;
    constexpr float DirtSlopeThresholdDegrees = 16.0f;
    constexpr float RockSlopeThresholdDegrees = 28.0f;
    constexpr float SteepRockThresholdDegrees = 38.0f;

    const float SeaLevel = static_cast<float>(TerrainSnapshot.SeaLevelVoxels);

    const bool bUnderWater = SurfaceHeight <= SeaLevel;
    const bool bCoastalShallow =
        SurfaceHeight > SeaLevel &&
        SurfaceHeight <= (SeaLevel + CoastBandVoxels);

    // Match the map-side rules:
    // underwater = water, shoreline just above sea level = sand
    if (bUnderWater)
    {
        return TerrainLayer_Sand;
    }

    if (bCoastalShallow)
    {
        return TerrainLayer_Sand;
    }

    if (NormalizedElevation >= SnowMinElevationNormalizedLocal)
    {
        return TerrainLayer_Snow;
    }

    if (SlopeDegrees >= SteepRockThresholdDegrees)
    {
        return TerrainLayer_Rock;
    }

    if (NormalizedElevation >= UpperRockElevationNormalizedLocal)
    {
        return (SlopeDegrees >= RockSlopeThresholdDegrees)
            ? TerrainLayer_Rock
            : TerrainLayer_Dirt;
    }

    if (NormalizedElevation >= HighlandDirtElevationNormalizedLocal)
    {
        return (SlopeDegrees >= RockSlopeThresholdDegrees)
            ? TerrainLayer_Rock
            : TerrainLayer_Dirt;
    }

    if (SlopeDegrees >= DirtSlopeThresholdDegrees)
    {
        return TerrainLayer_Dirt;
    }

    // Favor grass much more
    if (NormalizedElevation < 0.6f)
    {
        return TerrainLayer_Grass;
    }

    return TerrainLayer_Dirt;
}

FVoxelMaterial FWorldForgeTerrainGeneratorInstance::MakeVoxelMaterialFromLayer(int32 MaterialLayer) const
{
    FVoxelMaterialBuilder Builder;
    Builder.SetMaterialConfig(EVoxelMaterialConfig::SingleIndex);

    const uint8 SafeLayer = static_cast<uint8>(FMath::Clamp(MaterialLayer, 0, 255));
    Builder.SetSingleIndex(SafeLayer);

    return Builder.Build();
}

bool FWorldForgeTerrainGeneratorInstance::IsSnapshotValid() const
{
    return TerrainSnapshot.IsValid();
}

FIntPoint FWorldForgeTerrainGeneratorInstance::ClampChunkCell(const FIntPoint& Cell) const
{
    return TerrainSnapshot.ClampCell(Cell);
}

int32 FWorldForgeTerrainGeneratorInstance::ComputeChunkBaseDepthVoxels(const FVoxelBiomeProfile& Profile) const
{
    const float SafeVoxelSize = (TerrainSnapshot.VoxelSize > KINDA_SMALL_NUMBER)
        ? TerrainSnapshot.VoxelSize
        : 100.0f;

    const int32 DerivedDepth = FMath::RoundToInt(Profile.NoiseAmplitude / SafeVoxelSize);
    return FMath::Max(12, DerivedDepth);
}