#pragma once

#include "CoreMinimal.h"
#include "GameplayTagContainer.h"
#include "NativeGameplayTags.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "WorldForgeTags.generated.h"

// ====================================================================
// WorldForgeTags -- all gameplay tags used in C++ logic.
// Declare here, define in WorldForgeTags.cpp.
// Never use .ToString().Contains() for tag logic -- use these instead.
// ====================================================================

// ---- Job tags ------------------------------------------------------
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Job_Eat);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Job_Sleep);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Job_Haul);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Job_Cook);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Job_Craft);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Job_Build);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Job_Idle);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Job_Harvest_Food);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Job_Harvest_Wood);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Job_Harvest_Stone);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Job_Mine);

// ---- Job category parent tags --------------------------------------
// Correct usage:
// TAG_Job_Harvest_Food.MatchesTag(TAG_Job_Harvest) returns true
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Job_Harvest);

// ---- Item tags -----------------------------------------------------
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Item_Food);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Item_Wood);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Item_Stone);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Item_IronOre);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Item_IronBar);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Item_Meal);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Item_Ale);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Item_Plank);

// ---- Skill tags ----------------------------------------------------
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Skill_Farming);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Skill_Mining);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Skill_Cooking);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Skill_Crafting);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Skill_Hauling);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Skill_Building);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Skill_Research);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Skill_Medicine);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Skill_Combat);

// ---- Race tags ------------------------------------------------------
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Race_Dwarf);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Race_HighElf);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Race_Human);

// ---- Race mechanic tags --------------------------------------------
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Race_Mechanic_PressureLimit);

// ---- Currency tags -------------------------------------------------
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Currency_Barter);

// ---- Economy narrative pattern tags --------------------------------
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Economy_Pattern_Famine);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Economy_Pattern_CurrencyFreefall);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Economy_Pattern_Boom);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Economy_Pattern_Monopoly);

// ---- Simulation event tags -----------------------------------------
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Sim_Event_NeedFoodCritical);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Sim_Event_NeedCritical);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Sim_Event_JobAssigned);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Sim_Event_JobCancelled);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Sim_Event_ProductionComplete);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Sim_Event_BuildingComplete);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Sim_Event_ColonistDied);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Sim_Event_ColonistInjured);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Sim_Event_MoraleCrisis);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Sim_Event_StockpileEmpty);

// ---- Building tags -------------------------------------------------
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Building_Housing_Hut);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Building_Storage_Stockpile);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Building_Production_Kitchen);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Building_Production_Carpenter);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Building_Defense_Barracks);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Building_Spiritual_Shrine);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Building_Economic_MarketStall);

// ====================================================================
// Phase 1: Digging & Mining Tags
// ====================================================================

// ---- Tool tags -----------------------------------------------------
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Tool_Dig);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Tool_Mine);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Tool_Pickaxe);

// ---- Terrain block type tags ---------------------------------------
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Terrain_Dirt);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Terrain_Stone);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Terrain_Gravel);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Terrain_Clay);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Terrain_Sand);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Terrain_Bedrock);

// ---- Depth tier tags -----------------------------------------------
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_DepthTier_Surface);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_DepthTier_Shallow);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_DepthTier_Mid);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_DepthTier_Deep);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_DepthTier_Abyss);

// ---- Resource tags -------------------------------------------------
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Resource_Stone);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Resource_Iron);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Resource_Copper);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Resource_Coal);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Resource_Tin);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Resource_Silver);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Resource_Gold);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Resource_Quartz);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Resource_Mithril);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Resource_Obsidian);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Resource_VoidCrystal);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Resource_Starstone);

// ---- Batch 3: Resource Discovery category tags ---------------------
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Resource_Crystal);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Resource_Fossil);

// ════════════════════════════════════════════════════════════════════
// Wild Harvest Integration — Farming Tags
// ════════════════════════════════════════════════════════════════════

// ---- Farming job tags --------------------------------------------------
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Job_Farm_PrepSoil);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Job_Farm_Plant);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Job_Farm_Water);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Job_Farm_Harvest);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Job_Farm_Clear);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Job_Farm_Fertilize);

// ---- Farming item tags -------------------------------------------------
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Item_Grain);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Item_Berries);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Item_RootVeg);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Item_Greens);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Item_Herbs);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Item_Mushrooms);

// ---- Farming sim event tags --------------------------------------------
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Sim_Event_CropHarvested);
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Sim_Event_CropDied);

// ════════════════════════════════════════════════════════════════════
// Structural Stability System Tags
// ════════════════════════════════════════════════════════════════════

// Fired by UStabilitySubsystem::ProcessCollapses() whenever one or more
// ceiling voxels lose structural support and cave in.
// Payload carriers: FCollapseResult (collapsed voxel list + injured agent IDs).
// HealthProcessor subscribes to apply cave-in damage to injured agents.
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Sim_Event_CaveCollapse);

// Fired when a named colonist survives a collapse (within injury radius
// but not killed). Source for narrative / Commander's Desk entries.
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Sim_Event_ColonistEscapedCollapse);

// Identifies the Structural Stability debug overlay (overlay #15).
// Colours ceiling voxels near mined areas by their span-stability tier.
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Overlay_Stability);

// ====================================================================
// Blueprint Access Library
// ====================================================================

UCLASS()
class WORLDFORGE_API UWorldForgeTagLibrary : public UBlueprintFunctionLibrary
{
    GENERATED_BODY()

public:

    // ---- Job tags --------------------------------------------------
    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Job")
    static FGameplayTag GetJobEatTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Job")
    static FGameplayTag GetJobSleepTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Job")
    static FGameplayTag GetJobHaulTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Job")
    static FGameplayTag GetJobCookTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Job")
    static FGameplayTag GetJobCraftTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Job")
    static FGameplayTag GetJobBuildTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Job")
    static FGameplayTag GetJobIdleTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Job")
    static FGameplayTag GetJobHarvestTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Job")
    static FGameplayTag GetJobHarvestFoodTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Job")
    static FGameplayTag GetJobHarvestWoodTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Job")
    static FGameplayTag GetJobHarvestStoneTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Job")
    static FGameplayTag GetJobMineTag();

    // ---- Item tags -------------------------------------------------
    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Item")
    static FGameplayTag GetItemFoodTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Item")
    static FGameplayTag GetItemWoodTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Item")
    static FGameplayTag GetItemStoneTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Item")
    static FGameplayTag GetItemIronOreTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Item")
    static FGameplayTag GetItemIronBarTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Item")
    static FGameplayTag GetItemMealTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Item")
    static FGameplayTag GetItemAleTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Item")
    static FGameplayTag GetItemPlankTag();

    // ---- Skill tags ------------------------------------------------
    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Skill")
    static FGameplayTag GetSkillFarmingTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Skill")
    static FGameplayTag GetSkillMiningTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Skill")
    static FGameplayTag GetSkillCookingTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Skill")
    static FGameplayTag GetSkillCraftingTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Skill")
    static FGameplayTag GetSkillHaulingTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Skill")
    static FGameplayTag GetSkillBuildingTag();

    // ---- Currency tags ---------------------------------------------
    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Currency")
    static FGameplayTag GetCurrencyBarterTag();

    // ---- Economy pattern tags --------------------------------------
    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Economy")
    static FGameplayTag GetEconomyPatternFamineTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Economy")
    static FGameplayTag GetEconomyPatternCurrencyFreefallTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Economy")
    static FGameplayTag GetEconomyPatternBoomTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Economy")
    static FGameplayTag GetEconomyPatternMonopolyTag();

    // ---- Simulation event tags -------------------------------------
    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Event")
    static FGameplayTag GetNeedFoodCriticalEventTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Event")
    static FGameplayTag GetNeedCriticalEventTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Event")
    static FGameplayTag GetJobAssignedEventTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Event")
    static FGameplayTag GetJobCancelledEventTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Event")
    static FGameplayTag GetProductionCompleteEventTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Event")
    static FGameplayTag GetBuildingCompleteEventTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Event")
    static FGameplayTag GetColonistDiedEventTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Event")
    static FGameplayTag GetColonistInjuredEventTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Event")
    static FGameplayTag GetMoraleCrisisEventTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Event")
    static FGameplayTag GetStockpileEmptyEventTag();

    // ---- Building tags ---------------------------------------------
    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Building")
    static FGameplayTag GetBuildingHousingHutTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Building")
    static FGameplayTag GetBuildingStorageStockpileTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Building")
    static FGameplayTag GetBuildingProductionKitchenTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Building")
    static FGameplayTag GetBuildingProductionCarpenterTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Building")
    static FGameplayTag GetBuildingDefenseBarracksTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Building")
    static FGameplayTag GetBuildingSpiritualShrineTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Building")
    static FGameplayTag GetBuildingEconomicMarketStallTag();

    // ---- Batch 3: Resource Discovery category tags -----------------
    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Resource")
    static FGameplayTag GetResourceCrystalTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Resource")
    static FGameplayTag GetResourceFossilTag();

    // ════ Wild Harvest Integration ════

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Job")
    static FGameplayTag GetJobFarmPrepSoilTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Job")
    static FGameplayTag GetJobFarmPlantTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Job")
    static FGameplayTag GetJobFarmWaterTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Job")
    static FGameplayTag GetJobFarmHarvestTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Job")
    static FGameplayTag GetJobFarmClearTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Job")
    static FGameplayTag GetJobFarmFertilizeTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Item")
    static FGameplayTag GetItemGrainTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Item")
    static FGameplayTag GetItemBerriesTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Item")
    static FGameplayTag GetItemRootVegTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Item")
    static FGameplayTag GetItemGreensTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Item")
    static FGameplayTag GetItemHerbsTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Item")
    static FGameplayTag GetItemMushroomsTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Event")
    static FGameplayTag GetCropHarvestedEventTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Event")
    static FGameplayTag GetCropDiedEventTag();

    // ════ Structural Stability ════

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Event")
    static FGameplayTag GetCaveCollapseEventTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Event")
    static FGameplayTag GetColonistEscapedCollapseEventTag();

    UFUNCTION(BlueprintPure, Category = "WorldForge|Tags|Overlay")
    static FGameplayTag GetOverlayStabilityTag();
};
