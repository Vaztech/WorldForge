#include "BuildModeWidget.h"
#include "Player/BuildModeManager.h"
#include "WorldForgeDataRegistry.h"
#include "Engine/GameInstance.h"
#include "Engine/World.h"
#include "Player/WorldForgePlayerController.h"

UBuildModeManager* UBuildModeWidget::GetManager()
{
	if (CachedManager)
	{
		return CachedManager;
	}

	UWorld* W = GetWorld();
	if (W)
	{
		CachedManager = W->GetSubsystem<UBuildModeManager>();
	}

	return CachedManager;
}

UWorldForgeDataRegistry* UBuildModeWidget::GetRegistry() const
{
	if (UGameInstance* GI = GetGameInstance())
	{
		return GI->GetSubsystem<UWorldForgeDataRegistry>();
	}

	return nullptr;
}

namespace
{
	static void WF_ExitMineModeBeforeNonMineTool(UBuildModeWidget* Widget)
	{
		if (!Widget)
		{
			return;
		}

		if (AWorldForgePlayerController* PC = Widget->GetOwningPlayer<AWorldForgePlayerController>())
		{
			PC->ExecuteExitMineModeIfActive();
		}
	}
}

void UBuildModeWidget::NativeConstruct()
{
	Super::NativeConstruct();

	UBuildModeManager* Mgr = GetManager();
	if (!Mgr)
	{
		return;
	}

	Mgr->OnBuildModeChanged.AddDynamic(this, &UBuildModeWidget::OnBuildModeChanged);
	Mgr->OnCellCountChanged.AddDynamic(this, &UBuildModeWidget::OnCellCountChanged);
	Mgr->OnHoveredCellChanged.AddDynamic(this, &UBuildModeWidget::OnHoveredCellChanged);
	Mgr->OnBuildSelectionChanged.AddDynamic(this, &UBuildModeWidget::OnSelectionChanged);
	Mgr->OnBuildFeedbackMessage.AddDynamic(this, &UBuildModeWidget::OnBuildFeedbackMessage);

	// Push initial state so the widget has valid data immediately on show.
	OnBuildModeChanged(Mgr->GetCurrentMode());
	OnCellCountChanged(Mgr->GetSelectedCellCount());
	OnSelectionChanged(
		Mgr->GetCurrentMode(),
		Mgr->GetSelectedBuildingTag(),
		Mgr->GetSelectedMaterialTag()
	);

	if (Mgr->HasValidHoveredCell())
	{
		OnHoveredCellChanged(Mgr->GetHoveredCell());
	}

	// Push an initial stockpile snapshot for whichever selection is currently active.
	OnStockpileChanged(Mgr->GetCurrentRequiredItemTag(), Mgr->GetCurrentAvailableUnits());

	UE_LOG(LogTemp, Log, TEXT("[BuildModeWidget] Constructed and bound to BuildModeManager."));
}

void UBuildModeWidget::NativeDestruct()
{
	UBuildModeManager* Mgr = GetManager();
	if (Mgr)
	{
		Mgr->OnBuildModeChanged.RemoveDynamic(this, &UBuildModeWidget::OnBuildModeChanged);
		Mgr->OnCellCountChanged.RemoveDynamic(this, &UBuildModeWidget::OnCellCountChanged);
		Mgr->OnHoveredCellChanged.RemoveDynamic(this, &UBuildModeWidget::OnHoveredCellChanged);
		Mgr->OnBuildSelectionChanged.RemoveDynamic(this, &UBuildModeWidget::OnSelectionChanged);
		Mgr->OnBuildFeedbackMessage.RemoveDynamic(this, &UBuildModeWidget::OnBuildFeedbackMessage);
	}

	CachedManager = nullptr;

	Super::NativeDestruct();
}

// ================================
// Actions (called from Blueprint buttons)
// ================================

void UBuildModeWidget::SelectPrefabBuilding(FGameplayTag BuildingTag)
{
	UBuildModeManager* Mgr = GetManager();
	if (!Mgr)
	{
		return;
	}

	WF_ExitMineModeBeforeNonMineTool(this);

	Mgr->EnterPrefabMode(BuildingTag);

	OnStockpileChanged(Mgr->GetCurrentRequiredItemTag(), Mgr->GetCurrentAvailableUnits());

	UE_LOG(LogTemp, Log, TEXT("[BuildModeWidget] Prefab selected: %s"), *BuildingTag.ToString());
}

void UBuildModeWidget::SelectMaterial(FGameplayTag MaterialTag)
{
	UBuildModeManager* Mgr = GetManager();
	if (!Mgr)
	{
		return;
	}

	WF_ExitMineModeBeforeNonMineTool(this);

	if (Mgr->GetCurrentMode() == EBuildMode::CustomDraw)
	{
		Mgr->ExitBuildMode();
	}

	Mgr->EnterCustomDrawMode(MaterialTag);

	OnStockpileChanged(Mgr->GetCurrentRequiredItemTag(), Mgr->GetCurrentAvailableUnits());

	UE_LOG(LogTemp, Log, TEXT("[BuildModeWidget] Material selected: %s"), *MaterialTag.ToString());
}

void UBuildModeWidget::SwitchToCustomDrawMode()
{
	UBuildModeManager* Mgr = GetManager();
	if (!Mgr) return;

	WF_ExitMineModeBeforeNonMineTool(this);

	FGameplayTag DefaultMaterial = FGameplayTag::RequestGameplayTag(
		FName(TEXT("WorldForge.Voxel.Material.Stone")));

	Mgr->EnterCustomDrawMode(DefaultMaterial);

	OnStockpileChanged(Mgr->GetCurrentRequiredItemTag(), Mgr->GetCurrentAvailableUnits());

	UE_LOG(LogTemp, Log, TEXT("[BuildModeWidget] Switched to custom draw mode."));
}


void UBuildModeWidget::SwitchToDigMode()
{
	UBuildModeManager* Mgr = GetManager();
	if (!Mgr)
	{
		return;
	}

	WF_ExitMineModeBeforeNonMineTool(this);

	Mgr->EnterDigMode();

	// Dig has no material/building cost in Phase 1.
	OnStockpileChanged(FGameplayTag::EmptyTag, 0);

	UE_LOG(LogTemp, Log, TEXT("[BuildModeWidget] Switched to dig mode."));
}

void UBuildModeWidget::SwitchToMineMode()
{
	AWorldForgePlayerController* PC = GetOwningPlayer<AWorldForgePlayerController>();
	if (PC)
	{
		PC->ExecuteToggleMineMode();
		OnStockpileChanged(FGameplayTag::EmptyTag, 0);
		UE_LOG(LogTemp, Log, TEXT("[BuildModeWidget] Toggled mine mode via player controller."));
		return;
	}

	// Fallback only. This enters Mine mode but cannot activate controller-owned
	// camera/cutaway subsystems, so the player controller path above is preferred.
	UBuildModeManager* Mgr = GetManager();
	if (!Mgr)
	{
		return;
	}

	Mgr->EnterMineMode();
	OnStockpileChanged(FGameplayTag::EmptyTag, 0);
	UE_LOG(LogTemp, Warning, TEXT("[BuildModeWidget] Switched to mine mode through manager fallback."));
}

void UBuildModeWidget::SwitchToFarmMode()
{
	UBuildModeManager* Mgr = GetManager();
	if (!Mgr)
	{
		return;
	}

	WF_ExitMineModeBeforeNonMineTool(this);

	// Safety guard: if the Farm button is clicked while Farm mode already has
	// painted cells, commit the farm selection instead of toggling/canceling it.
	// This protects Blueprint wiring where the same button may be reused as a
	// confirm-style action after painting.
	if (Mgr->GetCurrentToolMode() == EBuildToolMode::Farm && Mgr->GetSelectedCellCount() > 0)
	{
		Mgr->HandleConfirm();
		OnStockpileChanged(FGameplayTag::EmptyTag, 0);
		UE_LOG(LogTemp, Log, TEXT("[BuildModeWidget] Farm mode already active; confirming farm selection."));
		return;
	}

	Mgr->EnterFarmMode();

	OnStockpileChanged(FGameplayTag::EmptyTag, 0);

	UE_LOG(LogTemp, Log, TEXT("[BuildModeWidget] Switched to farm mode."));
}

void UBuildModeWidget::CancelBuild()
{
	UBuildModeManager* Mgr = GetManager();
	if (!Mgr)
	{
		return;
	}

	// Mine mode owns extra controller/camera/cutaway state. Exit through the
	// player controller so TerrainCutawaySubsystem and mining camera state are
	// properly cleaned up.
	if (Mgr->IsInMineMode())
	{
		if (AWorldForgePlayerController* PC = GetOwningPlayer<AWorldForgePlayerController>())
		{
			PC->ExecuteToggleMineMode();
			return;
		}
	}

	Mgr->HandleCancel();
}

void UBuildModeWidget::ConfirmBuild()
{
	UBuildModeManager* Mgr = GetManager();
	if (!Mgr)
	{
		return;
	}

	UE_LOG(LogTemp, Log, TEXT("[BuildModeWidget] ConfirmBuild pressed. ToolMode=%d CellCount=%d"),
		static_cast<int32>(Mgr->GetCurrentToolMode()),
		Mgr->GetSelectedCellCount());

	Mgr->HandleConfirm();
}


void UBuildModeWidget::ToggleStaticGridOverlay()
{
	if (UBuildModeManager* Mgr = GetManager())
	{
		const bool bEnabled = Mgr->ToggleStaticBaseGrid();
		UE_LOG(LogTemp, Log, TEXT("[BuildModeWidget] Static grid overlay toggled: %s"), bEnabled ? TEXT("ON") : TEXT("OFF"));
	}
}

void UBuildModeWidget::SetStaticGridOverlayEnabled(bool bEnabled)
{
	if (UBuildModeManager* Mgr = GetManager())
	{
		Mgr->SetStaticBaseGridEnabled(bEnabled);
		UE_LOG(LogTemp, Log, TEXT("[BuildModeWidget] Static grid overlay set: %s"), bEnabled ? TEXT("ON") : TEXT("OFF"));
	}
}

bool UBuildModeWidget::IsStaticGridOverlayEnabled() const
{
	const UBuildModeManager* Mgr = const_cast<UBuildModeWidget*>(this)->GetManager();
	return Mgr && Mgr->IsStaticBaseGridEnabled();
}

void UBuildModeWidget::ToggleMiningRemovalMode()
{
	UBuildModeManager* Mgr = GetManager();
	if (!Mgr)
	{
		return;
	}

	Mgr->ToggleMiningRemovalMode();
	UE_LOG(LogTemp, Log, TEXT("[BuildModeWidget] Toggled mining removal mode."));
}

void UBuildModeWidget::SetMiningRemovalMode(EMiningRemovalMode NewMode)
{
	UBuildModeManager* Mgr = GetManager();
	if (!Mgr)
	{
		return;
	}

	Mgr->SetMiningRemovalMode(NewMode);
	UE_LOG(LogTemp, Log, TEXT("[BuildModeWidget] Set mining removal mode: %d"), static_cast<int32>(NewMode));
}

EMiningRemovalMode UBuildModeWidget::GetMiningRemovalMode() const
{
	const UBuildModeManager* Mgr = const_cast<UBuildModeWidget*>(this)->GetManager();
	return Mgr ? Mgr->GetMiningRemovalMode() : EMiningRemovalMode::VoxelCube;
}

FText UBuildModeWidget::GetMiningRemovalModeLabel() const
{
	const UBuildModeManager* Mgr = const_cast<UBuildModeWidget*>(this)->GetManager();
	return Mgr ? Mgr->GetMiningRemovalModeText() : FText::FromString(TEXT("Mining: Voxel Cube"));
}


void UBuildModeWidget::ToggleMiningHeightMode()
{
	UBuildModeManager* Mgr = GetManager();
	if (!Mgr)
	{
		return;
	}

	const EWFMiningHeightMode NewMode = Mgr->ToggleMiningHeightMode();
	UE_LOG(LogTemp, Log, TEXT("[BuildModeWidget] Toggled mining height mode: %d"), static_cast<int32>(NewMode));
}

void UBuildModeWidget::SetMiningHeightMode(EWFMiningHeightMode NewMode)
{
	UBuildModeManager* Mgr = GetManager();
	if (!Mgr)
	{
		return;
	}

	Mgr->SetMiningHeightMode(NewMode);
	UE_LOG(LogTemp, Log, TEXT("[BuildModeWidget] Set mining height mode: %d"), static_cast<int32>(NewMode));
}

EWFMiningHeightMode UBuildModeWidget::GetMiningHeightMode() const
{
	const UBuildModeManager* Mgr = const_cast<UBuildModeWidget*>(this)->GetManager();
	return Mgr ? Mgr->GetMiningHeightMode() : EWFMiningHeightMode::TwoVoxelColumn;
}

FText UBuildModeWidget::GetMiningHeightModeLabel() const
{
	const UBuildModeManager* Mgr = const_cast<UBuildModeWidget*>(this)->GetManager();
	return Mgr ? Mgr->GetMiningHeightModeText() : FText::FromString(TEXT("Mine Height: 2 Block Column"));
}

// ================================
// Read-only data accessors for Blueprint UI
// ================================

TArray<FGameplayTag> UBuildModeWidget::GetAvailableBuildingTags() const
{
	TArray<FGameplayTag> Result;

	if (const UWorldForgeDataRegistry* Registry = GetRegistry())
	{
		const TMap<FGameplayTag, UBuildingDefinition*>& Buildings = Registry->GetAllBuildings();

		for (const TPair<FGameplayTag, UBuildingDefinition*>& Pair : Buildings)
		{
			if (Pair.Key.IsValid() && Pair.Value)
			{
				Result.Add(Pair.Key);
			}
		}
	}

	return Result;
}

TArray<FGameplayTag> UBuildModeWidget::GetAvailableMaterialTags() const
{
	TArray<FGameplayTag> Result;

	Result.Add(FGameplayTag::RequestGameplayTag(FName(TEXT("WorldForge.Voxel.Material.Stone"))));
	Result.Add(FGameplayTag::RequestGameplayTag(FName(TEXT("WorldForge.Voxel.Material.Wood"))));

	return Result;
}

FText UBuildModeWidget::GetBuildingDisplayName(FGameplayTag BuildingTag) const
{
	if (!BuildingTag.IsValid())
	{
		return FText::FromString(TEXT("None"));
	}

	if (const UWorldForgeDataRegistry* Registry = GetRegistry())
	{
		if (const UBuildingDefinition* Def = Registry->FindBuilding(BuildingTag))
		{
			if (!Def->DisplayName.IsEmpty())
			{
				return Def->DisplayName;
			}
		}
	}

	return FText::FromString(BuildingTag.ToString());
}

FText UBuildModeWidget::GetItemDisplayName(FGameplayTag ItemTag) const
{
	if (!ItemTag.IsValid())
	{
		return FText::FromString(TEXT("None"));
	}

	if (const UWorldForgeDataRegistry* Registry = GetRegistry())
	{
		if (const UItemDefinition* Def = Registry->FindItem(ItemTag))
		{
			if (!Def->DisplayName.IsEmpty())
			{
				return Def->DisplayName;
			}
		}
	}

	return FText::FromString(ItemTag.ToString());
}

FText UBuildModeWidget::GetMaterialDisplayName(FGameplayTag MaterialTag) const
{
	if (!MaterialTag.IsValid())
	{
		return FText::FromString(TEXT("None"));
	}

	// If you later add voxel-material registry assets, resolve them here.
	return FText::FromString(MaterialTag.ToString());
}

FText UBuildModeWidget::GetSelectedBuildingDisplayName() const
{
	const UBuildModeManager* Mgr = const_cast<UBuildModeWidget*>(this)->GetManager();
	return Mgr
		? GetBuildingDisplayName(Mgr->GetSelectedBuildingTag())
		: FText::FromString(TEXT("None"));
}

FText UBuildModeWidget::GetSelectedMaterialDisplayName() const
{
	const UBuildModeManager* Mgr = const_cast<UBuildModeWidget*>(this)->GetManager();
	return Mgr
		? GetMaterialDisplayName(Mgr->GetSelectedMaterialTag())
		: FText::FromString(TEXT("None"));
}

FText UBuildModeWidget::GetCurrentCostLabel() const
{
	const UBuildModeManager* Mgr = const_cast<UBuildModeWidget*>(this)->GetManager();
	if (!Mgr)
	{
		return FText::FromString(TEXT("Cost: N/A"));
	}

	if (Mgr->GetCurrentToolMode() == EBuildToolMode::Dig ||
		Mgr->GetCurrentToolMode() == EBuildToolMode::Mine ||
		Mgr->GetCurrentToolMode() == EBuildToolMode::Farm)
	{
		return FText::FromString(TEXT("Cost: None"));
	}

	const int32 RequiredUnits = Mgr->GetCurrentRequiredUnits();
	const FGameplayTag RequiredItemTag = Mgr->GetCurrentRequiredItemTag();

	if (!RequiredItemTag.IsValid() || RequiredUnits <= 0)
	{
		return FText::FromString(TEXT("Cost: N/A"));
	}

	const FText ItemName = GetItemDisplayName(RequiredItemTag);

	return FText::Format(
		NSLOCTEXT("WorldForge", "BuildMode_CurrentCost", "Cost: {0} x {1}"),
		FText::AsNumber(RequiredUnits),
		ItemName
	);
}

FText UBuildModeWidget::GetCurrentAvailabilityLabel() const
{
	const UBuildModeManager* Mgr = const_cast<UBuildModeWidget*>(this)->GetManager();
	if (!Mgr)
	{
		return FText::FromString(TEXT("Available: N/A"));
	}

	if (Mgr->GetCurrentToolMode() == EBuildToolMode::Dig ||
		Mgr->GetCurrentToolMode() == EBuildToolMode::Mine ||
		Mgr->GetCurrentToolMode() == EBuildToolMode::Farm)
	{
		return FText::FromString(TEXT("Available: N/A"));
	}

	const int32 AvailableUnits = Mgr->GetCurrentAvailableUnits();
	const int32 RequiredUnits = Mgr->GetCurrentRequiredUnits();

	return FText::Format(
		NSLOCTEXT("WorldForge", "BuildMode_CurrentAvailability", "Available: {0} / Required: {1}"),
		FText::AsNumber(AvailableUnits),
		FText::AsNumber(RequiredUnits)
	);
}

bool UBuildModeWidget::GetCanAffordCurrentSelection() const
{
	const UBuildModeManager* Mgr = const_cast<UBuildModeWidget*>(this)->GetManager();
	if (!Mgr)
	{
		return false;
	}

	if (Mgr->GetCurrentToolMode() == EBuildToolMode::Dig ||
		Mgr->GetCurrentToolMode() == EBuildToolMode::Mine ||
		Mgr->GetCurrentToolMode() == EBuildToolMode::Farm)
	{
		return true;
	}

	return Mgr->CanAffordCurrentSelection();
}

int32 UBuildModeWidget::GetCurrentCellCount() const
{
	const UBuildModeManager* Mgr = const_cast<UBuildModeWidget*>(this)->GetManager();
	return Mgr ? Mgr->GetSelectedCellCount() : 0;
}

EBuildToolMode UBuildModeWidget::GetCurrentToolMode() const
{
	const UBuildModeManager* Mgr = const_cast<UBuildModeWidget*>(this)->GetManager();
	return Mgr ? Mgr->GetCurrentToolMode() : EBuildToolMode::None;
}

FText UBuildModeWidget::GetCurrentToolModeLabel() const
{
	const UBuildModeManager* Mgr = const_cast<UBuildModeWidget*>(this)->GetManager();
	if (!Mgr)
	{
		return FText::FromString(TEXT("Mode: None"));
	}

	switch (Mgr->GetCurrentToolMode())
	{
	case EBuildToolMode::Place:
		switch (Mgr->GetCurrentMode())
		{
		case EBuildMode::Prefab:
			return FText::FromString(TEXT("Mode: Prefab"));
		case EBuildMode::CustomDraw:
			return FText::FromString(TEXT("Mode: Free Build"));
		default:
			return FText::FromString(TEXT("Mode: Place"));
		}

	case EBuildToolMode::Remove:
		return FText::FromString(TEXT("Mode: Remove"));

	case EBuildToolMode::Dig:
		return FText::FromString(TEXT("Mode: Dig"));

	case EBuildToolMode::Mine:
		return FText::FromString(TEXT("Mode: Mine"));

	case EBuildToolMode::Farm:
		return FText::FromString(TEXT("Mode: Farm"));

	case EBuildToolMode::None:
	default:
		return FText::FromString(TEXT("Mode: None"));
	}
}

bool UBuildModeWidget::IsDigModeActive() const
{
	const UBuildModeManager* Mgr = const_cast<UBuildModeWidget*>(this)->GetManager();
	return Mgr && Mgr->GetCurrentToolMode() == EBuildToolMode::Dig;
}

bool UBuildModeWidget::IsMineModeActive() const
{
	const UBuildModeManager* Mgr = const_cast<UBuildModeWidget*>(this)->GetManager();
	return Mgr && Mgr->GetCurrentToolMode() == EBuildToolMode::Mine;
}

bool UBuildModeWidget::IsFarmModeActive() const
{
	const UBuildModeManager* Mgr = const_cast<UBuildModeWidget*>(this)->GetManager();
	return Mgr && Mgr->GetCurrentToolMode() == EBuildToolMode::Farm;
}