#pragma once

#include "CoreMinimal.h"
#include "GameplayTagContainer.h"
#include "Civilization/WorldHistory/WorldHistoryTypes.h"
#include "WorldForgeDataTypes.generated.h"

// ═══════════════════════════════════════════════════════════════════
// ENUMS
// ═══════════════════════════════════════════════════════════════════

UENUM(BlueprintType)
enum class EKnowledgeLevel : uint8
{
    Unexplored    UMETA(DisplayName = "Unexplored"),
    Outdated      UMETA(DisplayName = "Outdated"),
    Rumored       UMETA(DisplayName = "Rumored"),
    Surveyed      UMETA(DisplayName = "Surveyed"),
    Live          UMETA(DisplayName = "Live")
};

UENUM(BlueprintType)
enum class EWorldSize : uint8
{
    Small   UMETA(DisplayName = "Small (128x128)"),
    Medium  UMETA(DisplayName = "Medium (256x256)"),
    Large   UMETA(DisplayName = "Large (512x512)"),
    OMG     UMETA(DisplayName = "OMG (1024x1024)")
};

UENUM(BlueprintType)
enum class EPreHistoryEpoch : uint8
{
    Emergence      UMETA(DisplayName = "Emergence 0-500yr"),
    Expansion      UMETA(DisplayName = "Expansion 500-1000yr"),
    Conflict       UMETA(DisplayName = "Conflict 1000-1500yr"),
    Stabilization  UMETA(DisplayName = "Stabilization 1500-2000yr")
};

UENUM(BlueprintType)
enum class EAgentState : uint8
{
    Idle,
    SearchingForJob,
    ReservingTarget,
    MovingToTarget,
    Working,
    Carrying,
    Eating,
    Sleeping,
    Socializing,
    Fleeing,
    Fighting,
    Recovering,
    Incapacitated,
    Dead
};

UENUM(BlueprintType)
enum class EReservationType : uint8
{
    Item,
    Job,
    Building,
    Bed,
    InteractionSlot
};

UENUM(BlueprintType)
enum class EPriceFixType : uint8
{
    None,
    Ceiling,
    Floor,
    Ration,
    StandardBoard,
    GuildMonopoly,
    DivineMandated,
    Requisition
};

UENUM(BlueprintType)
enum class EMarketTier : uint8
{
    None,
    BasicStall,
    TradeHall,
    GrandExchange,
    BlackMarket
};

UENUM(BlueprintType)
enum class ETrustComponent : uint8
{
    MilitaryStability,
    BackingStrength,
    TradeReputation,
    CosmicFavor,
    PoliticalCohesion,
    GovernmentCredibility
};

UENUM(BlueprintType)
enum class EJobPriority : uint8
{
    Emergency = 4 UMETA(DisplayName = "Emergency"),
    High = 3 UMETA(DisplayName = "High"),
    Normal = 2 UMETA(DisplayName = "Normal"),
    Low = 1 UMETA(DisplayName = "Low"),
    Idle = 0 UMETA(DisplayName = "Idle")
};

UENUM(BlueprintType)
enum class EBuildingPurpose : uint8
{
    Housing        UMETA(DisplayName = "Housing"),
    Storage        UMETA(DisplayName = "Storage"),
    Production     UMETA(DisplayName = "Production"),
    Defense        UMETA(DisplayName = "Defense"),
    Infrastructure UMETA(DisplayName = "Infrastructure"),
    Spiritual      UMETA(DisplayName = "Spiritual"),
    Economic       UMETA(DisplayName = "Economic"),
    Decorative     UMETA(DisplayName = "Decorative")
};

UENUM(BlueprintType)
enum class ETerrainMode : uint8
{
    Smooth UMETA(DisplayName = "Smooth"),
    Blocky UMETA(DisplayName = "Blocky")
};

// ═══════════════════════════════════════════════════════════════════
// FOG OF WAR
// ═══════════════════════════════════════════════════════════════════

USTRUCT(BlueprintType)
struct FWorldKnowledgeState
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) int32 TileID = 0;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) EKnowledgeLevel KnowledgeLevel = EKnowledgeLevel::Unexplored;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) int32 LastSurveyYear = -1;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float DataAccuracy = 0.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) FString RumorSource;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) TArray<FGameplayTag> KnownCurrencies;
};

// ═══════════════════════════════════════════════════════════════════
// VOXEL
// ═══════════════════════════════════════════════════════════════════

USTRUCT(BlueprintType)
struct FVoxelBiomeProfile
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float NoiseFrequency = 0.02f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float NoiseAmplitude = 100.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) int32 OctaveCount = 4;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) bool bEnableCaves = true;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float CaveThreshold = 0.3f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) bool bSmoothSDF = true;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) TArray<FGameplayTag> SurfaceMaterials;
};

// ═══════════════════════════════════════════════════════════════════
// WORLD MAP
// ═══════════════════════════════════════════════════════════════════

USTRUCT(BlueprintType)
struct FWorldTileData
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) int32 TileID = 0;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) FGameplayTag BiomeType;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float Elevation = 0.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float WaterDepth = 0.f;
    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) float Temperature = 0.5f;
    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) float Rainfall = 0.5f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) TArray<FGameplayTag> ResourceNodes;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) TArray<FGameplayTag> ResourceTags;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) int32 ControllingCivID = -1;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) FWorldKnowledgeState KnowledgeState;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) FVoxelBiomeProfile VoxelProfile;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float Sacredness = 0.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float Corruption = 0.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float FearPressure = 0.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float DreamInstability = 0.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float CommercePressure = 0.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float VoidProximity = 0.f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) TArray<int32> HistoryEventIDs;

};

// ═══════════════════════════════════════════════════════════════════
// CIVILIZATION AND CULTURE
// ═══════════════════════════════════════════════════════════════════

USTRUCT(BlueprintType)
struct FCultureData
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) int32 CivID = 0;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float HierarchyTolerance = 50.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float OutgroupHostility = 50.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float LaborEthics = 50.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float Militarism = 50.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float MagicReverence = 50.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float Individualism = 50.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float TheologicalRigidity = 50.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float EconomicOpenness = 50.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float ExpansionDrive = 50.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float CosmicDevotion = 50.f;
};

USTRUCT(BlueprintType)
struct FHistoryEventData
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) int32 EventID = 0;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) int32 Year = 0;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) FGameplayTag EpochTag;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) TArray<int32> ParticipantIDs;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) FGameplayTag EventType;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) FString Result;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) FString Cause;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) TArray<FGameplayTag> NarrativeTags;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) int32 WorldTileID = -1;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float EconomicImpact = 0.f;
};

USTRUCT(BlueprintType)
struct FFigureRelationship
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    int32 TargetFigureID = -1;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    ERelationType RelationType = ERelationType::Ally;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    int32 FormedYear = 0;
};

USTRUCT(BlueprintType)
struct FHistoricalFigure
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    int32 FigureID = -1;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    FText Name;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    FText Epithet;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    FGameplayTag RaceTag;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    int32 CivID = -1;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    int32 BirthYear = 0;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    int32 DeathYear = -1;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    EHistoricalRole Role = EHistoricalRole::Hero;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    TArray<int32> KeyEventIDs;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    TArray<FGameplayTag> Skills;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    TArray<FFigureRelationship> Relationships;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    float LegacyScore = 0.f;
};

USTRUCT(BlueprintType)
struct FHistoricalEvent
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    int32 EventID = -1;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    FText Title;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    FText Description;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    int32 Year = 0;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    FGameplayTag EventType;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    TArray<int32> InvolvedFigureIDs;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    TArray<int32> InvolvedCivIDs;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    float HistoricalImpact = 0.5f;
};

USTRUCT(BlueprintType)
struct FLegendaryArtifact
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    int32 ArtifactID = -1;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    FText Name;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    FGameplayTag ItemTag;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    int32 CreatorFigureID = -1;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    int32 CreationYear = 0;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    int32 CreationEventID = -1;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    int32 CurrentOwnerCivID = -1;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    TMap<FGameplayTag, float> StatModifiers;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    FText LoreDescription;
};

USTRUCT(BlueprintType)
struct FArtifactOwnershipRecord
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    int32 ArtifactID = -1;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    int32 OwnerCivID = -1;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    int32 AcquiredEventID = -1;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    int32 LostEventID = -1;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    int32 StartYear = 0;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    int32 EndYear = 0;
};

USTRUCT(BlueprintType)
struct FMythRecord
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    int32 MythID = -1;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    FText Title;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    FText Description;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    int32 RelatedFigureID = -1;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    int32 RelatedArtifactID = -1;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    int32 OriginEventID = -1;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    float MythStrength = 0.5f;
};

USTRUCT(BlueprintType)
struct FCivilizationData
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) int32 CivID = 0;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) FGameplayTag RaceType;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) FGameplayTag GovernmentType;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) FGameplayTag CurrencyTag;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) FCultureData CulturalDNA;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) TMap<int32, float> RelationshipMap;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) int32 TechLevel = 1;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) FString Name;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) FString LegendaryFigure;

    // Phase 3.5 — RaceOrigin binding
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) FString RaceOrigin;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) bool bCollapsed = false;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) TArray<int32> ControlledTileIDs;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) TArray<int32> HistoryEventIDs;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) int32 TotalPopulation = 0;
};

// ═══════════════════════════════════════════════════════════════════
// ECONOMY
// ═══════════════════════════════════════════════════════════════════

USTRUCT(BlueprintType)
struct FCurrencyTrustState
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float MilitaryStability = 1.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float BackingStrength = 1.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float TradeReputation = 1.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float CosmicFavor = 1.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float PoliticalCohesion = 1.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float GovernmentCredibility = 1.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float TrustVelocity = 0.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) bool bInFreefall = false;
};

USTRUCT(BlueprintType)
struct FCurrencyDefinition
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) FGameplayTag CurrencyTag;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) FText DisplayName;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) FText PhysicalForm;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) int32 IssuingCivID = -1;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) FGameplayTag GovernmentType;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float BaseAnchorValue = 1.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float CurrentAnchorValue = 1.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float InflationRate = 0.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) FGameplayTag BackingType;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) TArray<int32> AcceptingCivIDs;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) bool bIsReserveCurrency = false;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) bool bInCrisis = false;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) bool bCollapsed = false;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) FCurrencyTrustState TrustState;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) TArray<FHistoryEventData> EconomicHistory;
};

USTRUCT(BlueprintType)
struct FPriceFixPolicy
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) FGameplayTag ItemTag;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) int32 CivID = -1;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) EPriceFixType FixType = EPriceFixType::None;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float FixedPrice = 0.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float EnforcementStrength = 0.5f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) bool bGeneratesBlackMarket = false;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float BlackMarketGap = 0.f;
};

USTRUCT(BlueprintType)
struct FGovernmentEconomicProfile
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) FGameplayTag GovernmentType;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float BaseTaxRate = 0.15f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float TariffRate = 0.10f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float EnforcementBudget = 0.5f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) TArray<FPriceFixPolicy> PriceFixPolicies;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) bool bAllowPrivateTrade = true;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) bool bAllowForeignMerchants = true;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) bool bStateMonopolyOnTrade = false;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float InnovationRate = 1.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float InequalityGrowthRate = 0.f;
};

USTRUCT(BlueprintType)
struct FMarketPrice
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) FGameplayTag ItemTag;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) int32 SettlementID = -1;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float BaseAnchorValue = 1.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float EquilibriumPrice = 1.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float OfficialPrice = 1.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float BlackMarketPrice = 0.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float SupplyPressure = 0.5f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float DemandPressure = 0.5f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float PriceElasticity = 0.7f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) bool bIsVeblenGood = false;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) bool bPriceFixed = false;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) EPriceFixType ActiveFixType = EPriceFixType::None;
};

USTRUCT(BlueprintType)
struct FSettlementState
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) int32 SettlementID = -1;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) int32 WorldTileID = -1;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) FString Name;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) int32 Population = 0;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float MoraleSummary = 50.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) FGameplayTag PlayerCurrencyTag;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) int32 OwnerCivID = -1;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float ThreatLevel = 0.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) TMap<FGameplayTag, int32> Stockpiles;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) TArray<FGameplayTag> CompletedBuildings;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) FGameplayTag ReligionState;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) FGameplayTagContainer ActivePolicies;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) bool bActorsLoaded = false;

    // NEW:
    // World-space terrain/grid origin for this settlement.
    // Local nav cells are converted to world terrain cells by:
    // WorldCell = WorldOrigin + LocalNavCell
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) FIntPoint WorldOrigin = FIntPoint::ZeroValue;
};

USTRUCT(BlueprintType)
struct FTradeFlowState
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) int32 RouteID = -1;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) int32 OriginID = -1;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) int32 DestID = -1;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float OfficialCapacity = 0.0f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float UnofficialCapacity = 0.0f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float SafetyFactor = 1.0f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float TaxFactor = 1.0f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float DiplomaticMod = 1.0f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) TMap<FGameplayTag, float> OfficialFlows;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) TMap<FGameplayTag, float> BlackMarketFlows;
};

USTRUCT(BlueprintType)
struct FMarketPriceArray
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    TArray<FMarketPrice> Items;
};

USTRUCT(BlueprintType)
struct FFloatHistoryArray
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    TArray<float> Values;
};

USTRUCT(BlueprintType)
struct FSettlementPriceHistory
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    TMap<FGameplayTag, FFloatHistoryArray> ItemHistory;
};

USTRUCT(BlueprintType)
struct FCurrencyTrustDelta
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) FGameplayTag CurrencyTag;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) ETrustComponent Component = ETrustComponent::MilitaryStability;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float Delta = 0.0f;
};

USTRUCT(BlueprintType)
struct FEconomySaveState
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    TMap<int32, FMarketPriceArray> SettlementPrices;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    TMap<int32, FSettlementPriceHistory> PriceHistory;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    TMap<FGameplayTag, FCurrencyTrustState> CurrencyTrust;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    TMap<FGameplayTag, FCurrencyDefinition> AllCurrencies;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    TMap<int32, FGovernmentEconomicProfile> CivGovernments;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    TMap<int32, FTradeFlowState> TradeRoutes;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    TArray<FCurrencyTrustDelta> PendingTrustDeltas;
};

// ═══════════════════════════════════════════════════════════════════
// COLONY SIMULATION
// ═══════════════════════════════════════════════════════════════════


USTRUCT(BlueprintType)
struct FReservationRecord
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) int32 ReservationID = -1;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) int32 OwnerAgentID = -1;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) int32 TargetID = -1;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) FGameplayTag TargetTag;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) EReservationType Type = EReservationType::Item;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) int32 CreatedOnStep = 0;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) int32 TimeoutSteps = 100;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) int32 SettlementID = -1;
};

USTRUCT(BlueprintType)
struct FNavCell
{
    GENERATED_BODY()

    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) FIntPoint GridPos = FIntPoint::ZeroValue;
    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) bool bWalkable = true;
    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) float PathCost = 1.0f;
    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) bool bDangerZone = false;
    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) int32 OccupantID = -1;
};

USTRUCT(BlueprintType)
struct FActiveBuildTask
{
    GENERATED_BODY()

    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) int32 TaskID = -1;
    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) int32 SettlementID = -1;
    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) FGameplayTag BuildingTag;
    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) FIntPoint OriginGridCell = FIntPoint::ZeroValue;
    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) int32 TotalBlocks = 0;
    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) int32 PlacedBlocks = 0;
    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) int32 AssignedAgentID = -1;
    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) bool bComplete = false;

    // Legacy flat custom-build data kept for backward compatibility with existing saves.
    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) TArray<FIntPoint> BlockList;

    // New canonical 3D block list.
    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) TArray<FIntVector> BlockList3D;

    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) FGameplayTag MaterialTag;
};

USTRUCT(BlueprintType)
struct FJobRequest
{
    GENERATED_BODY()

    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) int32 JobID = -1;
    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) int32 SettlementID = -1;
    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) FGameplayTag JobTag;
    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) FGameplayTag RequiredSkill;
    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) FGameplayTag TargetItemTag;
    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) FGameplayTag TargetBuildingTag;
    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) FIntPoint TargetGridPos = FIntPoint::ZeroValue;
    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) int32 TargetID = -1;
    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) EJobPriority Priority = EJobPriority::Normal;
    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) int32 AssignedAgentID = -1;
    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) bool bAssigned = false;
    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) int32 PostedOnStep = 0;
};

USTRUCT(BlueprintType)
struct FActiveProductionTask
{
    GENERATED_BODY()

    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) int32 TaskID = -1;
    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) int32 SettlementID = -1;
    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) FGameplayTag JobTag;
    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) FGameplayTag BuildingTag;
    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) int32 AssignedAgentID = -1;
    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) float Progress = 0.f;
    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) float RequiredProgress = 10.f;
    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) TMap<FGameplayTag, int32> InputsConsumed;
    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) TMap<FGameplayTag, int32> OutputItems;
    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) bool bInputsReserved = false;
    UPROPERTY(SaveGame, EditAnywhere, BlueprintReadWrite) bool bComplete = false;
};

USTRUCT(BlueprintType)
struct FAgentData
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) int32 AgentID = -1;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) int32 SettlementID = -1;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) EAgentState State = EAgentState::Idle;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) FGameplayTag RaceTag;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float FoodNeed = 100.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float SleepNeed = 100.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float SocialNeed = 60.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float SafetyNeed = 80.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float PurposeNeed = 70.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float MoodScore = 50.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) TArray<FString> RecentThoughts;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) TMap<FGameplayTag, float> Skills;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float EthicsPacifism = 50.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float EthicsCompassion = 50.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float EthicsHonour = 50.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float Health = 100.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) bool bInjured = false;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) int32 ActiveReservationID = -1;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) FGameplayTag CurrentJobTag;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) FGameplayTag CurrentJobBuildingTag;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) FIntPoint CurrentGridPos = FIntPoint::ZeroValue;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) FIntPoint CurrentNavTarget = FIntPoint::ZeroValue;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) TMap<FName, float> EntityFavor;
};

// ═══════════════════════════════════════════════════════════════════
// SIMULATION EVENTS
// ═══════════════════════════════════════════════════════════════════

USTRUCT(BlueprintType)
struct FSimulationEvent
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite) FGameplayTag EventType;
    UPROPERTY(EditAnywhere, BlueprintReadWrite) int32 SettlementID = -1;
    UPROPERTY(EditAnywhere, BlueprintReadWrite) int32 AgentID = -1;
    UPROPERTY(EditAnywhere, BlueprintReadWrite) int32 StepNumber = 0;
    UPROPERTY(EditAnywhere, BlueprintReadWrite) FGameplayTag Payload;
    UPROPERTY(EditAnywhere, BlueprintReadWrite) float FloatPayload = 0.f;
};

// ═══════════════════════════════════════════════════════════════════
// WORLD GENERATION CONFIG
// ═══════════════════════════════════════════════════════════════════

USTRUCT(BlueprintType)
struct FWorldGenConfig
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) EWorldSize WorldSize = EWorldSize::Medium;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) int32 PreHistoryYears = 200;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float WarFrequency = 0.5f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float DisasterFrequency = 0.5f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float MagicPrevalence = 0.5f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float CosmicDensity = 0.5f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) float EconomicComplexity = 0.5f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) int32 StartingCivCount = 4;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) int64 MasterSeed = 12345;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame) ETerrainMode TerrainMode = ETerrainMode::Smooth;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame, meta = (ClampMin = "1", UIMin = "1"))
    int32 BlockHeightStep = 4;
};

enum ECulturalAxis : int32
{
    CA_Hierarchy = 0,
    CA_OutgroupHostility = 1,
    CA_LaborEthics = 2,
    CA_Militarism = 3,
    CA_MagicReverence = 4,
    CA_Individualism = 5,
    CA_TheologicalRigid = 6,
    CA_EconomicOpenness = 7,
    CA_ExpansionDrive = 8,
    CA_CosmicDevotion = 9,
    CA_MAX = 10
};

UENUM()
enum class ECivilizationCollapseType : uint8
{
    None,
    Fragmentation,
    Diaspora,
    RefugeState,
    SplinterKingdom,
    UndergroundRetreat,
    ReligiousContinuation,
    EconomicCollapse
};

USTRUCT()
struct FResilienceRecord
{
    GENERATED_BODY()

    UPROPERTY(SaveGame) int32 CivID = -1;
    UPROPERTY(SaveGame) int32 ConsecutiveLowHealthTicks = 0;
    UPROPERTY(SaveGame) bool bHasCollapsed = false;
    UPROPERTY(SaveGame) ECivilizationCollapseType CollapseType = ECivilizationCollapseType::None;
    UPROPERTY(SaveGame) int32 CollapseStepNumber = -1;
};

USTRUCT()
struct FResilienceSaveState
{
    GENERATED_BODY()

    UPROPERTY(SaveGame) TArray<FResilienceRecord> Records;
};

USTRUCT()
struct FCargoItem
{
    GENERATED_BODY()

    UPROPERTY(SaveGame) FGameplayTag ItemTag;
    UPROPERTY(SaveGame) int32 Quantity = 0;
    UPROPERTY(SaveGame) float PricePerUnit = 1.0f;
};

USTRUCT()
struct FCaravanData
{
    GENERATED_BODY()

    UPROPERTY(SaveGame) int32 CaravanID = -1;
    UPROPERTY(SaveGame) int32 OriginSettlementID = -1;
    UPROPERTY(SaveGame) int32 DestSettlementID = -1;
    UPROPERTY(SaveGame) int32 StepsUntilArrival = 0;
    UPROPERTY(SaveGame) TArray<FCargoItem> Cargo;
    UPROPERTY(SaveGame) float PaymentAmount = 0.0f;
    UPROPERTY(SaveGame) FGameplayTag PaymentCurrencyTag;
    UPROPERTY(SaveGame) bool bOutbound = true;
};

UENUM()
enum class EOutpostType : uint8
{
    Resource,
    MilitaryFort,
    TradePost,
    NavalPort,
    SkyAnchor,
    MarketOutpost,
    DiplomaticMission,
    ShrineOutpost,
    ForwardBase
};

USTRUCT()
struct FOutpostData
{
    GENERATED_BODY()

    UPROPERTY(SaveGame) int32 OutpostID = -1;
    UPROPERTY(SaveGame) EOutpostType OutpostType = EOutpostType::Resource;
    UPROPERTY(SaveGame) int32 OwnerSettlementID = -1;
    UPROPERTY(SaveGame) FIntPoint WorldGridCell;
    UPROPERTY(SaveGame) int32 StaffCount = 0;
    UPROPERTY(SaveGame) int32 StepsWithoutSupply = 0;
    UPROPERTY(SaveGame) int32 LastSupplyArrivedStep = 0;
    UPROPERTY(SaveGame) bool bActive = true;
    UPROPERTY(SaveGame) float FlowRateMod = 1.0f;
};

USTRUCT()
struct FOverworldSaveState
{
    GENERATED_BODY()

    UPROPERTY(SaveGame) TArray<FCaravanData> ActiveCaravans;
    UPROPERTY(SaveGame) TArray<FOutpostData> ActiveOutposts;
    UPROPERTY(SaveGame) int32 NextCaravanID = 0;
    UPROPERTY(SaveGame) int32 NextOutpostID = 0;
};

UENUM()
enum class EDiplomaticActionType : uint8
{
    DeclareWar,
    ProposePeace,
    TradeAgreement,
    CurrencyPegging,
    EconomicAid,
    CurrencyWar,
    TradeEmbargo,
    SpyMission,
    CulturalExchange,
    MilitaryAlliance,
    Vassalize,
    OpenBorders,
    RequestTribute,
    HonorDebt,
    MarriageAlliance,
    JointExpedition
};

USTRUCT()
struct FDiplomaticTreaty
{
    GENERATED_BODY()

    UPROPERTY(SaveGame) int32 CivA = -1;
    UPROPERTY(SaveGame) int32 CivB = -1;
    UPROPERTY(SaveGame) EDiplomaticActionType TreatyType = EDiplomaticActionType::TradeAgreement;
    UPROPERTY(SaveGame) int32 ExpiryStep = -1;
    UPROPERTY(SaveGame) float FlowRateMod = 1.0f;
    UPROPERTY(SaveGame) bool bActive = true;
};

USTRUCT()
struct FDiplomacySaveState
{
    GENERATED_BODY()

    UPROPERTY(SaveGame) TMap<int64, float> RelationshipScores;
    UPROPERTY(SaveGame) TArray<FDiplomaticTreaty> ActiveTreaties;
    UPROPERTY(SaveGame) TArray<int32> EmbargoedCivIDs;
    UPROPERTY(SaveGame) TMap<int64, FGameplayTag> PeggedCurrencyPairs;
};

UENUM()
enum class EShipType : uint8
{
    Raft,
    RiverBarge,
    ScoutSloop
};

USTRUCT()
struct FShipData
{
    GENERATED_BODY()

    UPROPERTY(SaveGame) int32 ShipID = -1;
    UPROPERTY(SaveGame) EShipType ShipType = EShipType::Raft;
    UPROPERTY(SaveGame) int32 OwnerSettlementID = -1;
    UPROPERTY(SaveGame) float BaseSpeed = 1.0f;
    UPROPERTY(SaveGame) int32 CargoCap = 50;
    UPROPERTY(SaveGame) int32 OriginSettlementID = -1;
    UPROPERTY(SaveGame) int32 DestSettlementID = -1;
    UPROPERTY(SaveGame) int32 StepsUntilArrival = 0;
    UPROPERTY(SaveGame) TArray<FCargoItem> Cargo;
    UPROPERTY(SaveGame) bool bInTransit = false;
};

USTRUCT()
struct FNavalSaveState
{
    GENERATED_BODY()

    UPROPERTY(SaveGame) TArray<FShipData> ActiveShips;
    UPROPERTY(SaveGame) TArray<int32> BlockadedPortSettlementIDs;
    UPROPERTY(SaveGame) int32 NextShipID = 0;
};

UENUM()
enum class ECosmicEntityStatus : uint8
{
    Dormant,
    Emerging,
    Active,
    Fading,
    Gone
};

USTRUCT()
struct FCosmicEntityState
{
    GENERATED_BODY()

    UPROPERTY(SaveGame) int32 EntityID = -1;
    UPROPERTY(SaveGame) FGameplayTag EntityTag;
    UPROPERTY(SaveGame) ECosmicEntityStatus Status = ECosmicEntityStatus::Dormant;
    UPROPERTY(SaveGame) float TotalPower = 0.0f;

    UPROPERTY(SaveGame) float FearPower = 0.0f;
    UPROPERTY(SaveGame) float AffinityPower = 0.0f;
    UPROPERTY(SaveGame) float CatastrophePower = 0.0f;
    UPROPERTY(SaveGame) float AnchorPower = 0.0f;
    UPROPERTY(SaveGame) float BeliefPower = 0.0f;
    UPROPERTY(SaveGame) float IrritationPower = 0.0f;

    UPROPERTY(SaveGame) float FearDecayRate = 0.001f;
    UPROPERTY(SaveGame) float AffinityDecayRate = 0.001f;
    UPROPERTY(SaveGame) float CatastropheDecayRate = 0.002f;
    UPROPERTY(SaveGame) float AnchorDecayRate = 0.0005f;
    UPROPERTY(SaveGame) float BeliefDecayRate = 0.001f;
    UPROPERTY(SaveGame) float IrritationDecayRate = 0.003f;

    UPROPERTY(SaveGame) float EmergenceThreshold = 10.0f;
    UPROPERTY(SaveGame) float FadeThreshold = 1.0f;
    UPROPERTY(SaveGame) TArray<FGameplayTag> DomainTags;
    UPROPERTY(SaveGame) int32 FlowBoostStepsRemaining = 0;
    UPROPERTY(SaveGame) int32 FlowDrainStepsRemaining = 0;
    UPROPERTY(SaveGame) float FlowBoostMultiplier = 1.0f;
};

USTRUCT()
struct FAnchorRecord
{
    GENERATED_BODY()

    UPROPERTY(SaveGame) int32 AnchorID = -1;
    UPROPERTY(SaveGame) int32 SettlementID = -1;
    UPROPERTY(SaveGame) FIntPoint GridPosition;
    UPROPERTY(SaveGame) FGameplayTag BoundEntityTag;
    UPROPERTY(SaveGame) float PowerPerSimDay = 0.1f;
};

USTRUCT()
struct FNarrativePressureState
{
    GENERATED_BODY()

    UPROPERTY(SaveGame) float War = 0.0f;
    UPROPERTY(SaveGame) float Exploration = 0.0f;
    UPROPERTY(SaveGame) float Mysticism = 0.0f;
    UPROPERTY(SaveGame) float Fear = 0.0f;
    UPROPERTY(SaveGame) float Commerce = 0.0f;
    UPROPERTY(SaveGame) float Art = 0.0f;
    UPROPERTY(SaveGame) float CosmicUnstable = 0.0f;

    static constexpr float Threshold = 100.0f;
};

USTRUCT()
struct FCosmicSaveState
{
    GENERATED_BODY()

    UPROPERTY(SaveGame) TArray<FCosmicEntityState> EntityStates;
    UPROPERTY(SaveGame) TArray<FAnchorRecord> AnchorRecords;
    UPROPERTY(SaveGame) FNarrativePressureState NarrativePressure;
    UPROPERTY(SaveGame) int32 NextEntityID = 0;
    UPROPERTY(SaveGame) int32 NextAnchorID = 0;
};

// ═══════════════════════════════════════════════════════════════════
// VSS SAVE DATA
// ═══════════════════════════════════════════════════════════════════

USTRUCT(BlueprintType)
struct FVoxelSpawnRecord
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    FGameplayTag SimEntityTag;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    FIntPoint GridCell = FIntPoint::ZeroValue;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    FVector WorldPos = FVector::ZeroVector;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    FRotator Rotation = FRotator::ZeroRotator;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    FVector Scale = FVector(1.f, 1.f, 1.f);

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    int32 InstanceIdx = INDEX_NONE;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    int32 SettlementID = -1;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    bool bIsProp = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    bool bIsBlackMarket = false;
};

USTRUCT(BlueprintType)
struct FVSSSaveState
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, SaveGame)
    TArray<FVoxelSpawnRecord> SpawnRecords;
};